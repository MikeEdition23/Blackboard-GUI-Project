//@author David Stachnik

import javafx.stage.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

public class MultipleAnswer
{
	public static String course_Info_MA = "";
	public static void start()
	{
		
		//Window setup 
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Multiple Answer");
		window.setMinWidth(500);
		window.setMinHeight(500);
		
		//Text
		Label top = new Label();
		top.setText("Enter Question Info. You can type in the number of answers as you want.");
		
		//Text Fields for question info
		TextField questionText = new TextField();
		questionText.setPromptText("Question");
		
		TextField weightText = new TextField();
		weightText.setPromptText("Set the weight here. MUST be a number.");
		
		TextField choice1 = new TextField();
		choice1.setPromptText("Answer 1");
		
		ChoiceBox answer1 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox1 = new HBox(2);
		HBox1.getChildren().addAll(choice1, answer1);
		HBox1.setSpacing(10); 
		HBox1.setAlignment(Pos.CENTER);
		
		TextField choice2 = new TextField();
		choice2.setPromptText("Answer 2");
		
		ChoiceBox answer2 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox2 = new HBox(2);
		HBox2.getChildren().addAll(choice2, answer2);
		HBox2.setSpacing(10); 
		HBox2.setAlignment(Pos.CENTER);
		
		TextField choice3 = new TextField();
		choice3.setPromptText("Answer 3");
		
		ChoiceBox answer3 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox3 = new HBox(2);
		HBox3.getChildren().addAll(choice3, answer3);
		HBox3.setSpacing(10); 
		HBox3.setAlignment(Pos.CENTER);
		
		TextField choice4 = new TextField();
		choice4.setPromptText("Answer 4");
		
		ChoiceBox answer4 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox4 = new HBox(2);
		HBox4.getChildren().addAll(choice4, answer4);
		HBox4.setSpacing(10); 
		HBox4.setAlignment(Pos.CENTER);
		
		TextField choice5 = new TextField();
		choice5.setPromptText("Answer 5");
		
		ChoiceBox answer5 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox5 = new HBox(2);
		HBox5.getChildren().addAll(choice5, answer5);
		HBox5.setSpacing(10); 
		HBox5.setAlignment(Pos.CENTER);
		
		TextField choice6 = new TextField();
		choice6.setPromptText("Answer 6");
		
		ChoiceBox answer6 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox6 = new HBox(2);
		HBox6.getChildren().addAll(choice6, answer6);
		HBox6.setSpacing(10); 
		HBox6.setAlignment(Pos.CENTER);
		
		TextField choice7 = new TextField();
		choice7.setPromptText("Answer 7");
		
		ChoiceBox answer7 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox7 = new HBox(2);
		HBox7.getChildren().addAll(choice7, answer7);
		HBox7.setSpacing(10); 
		HBox7.setAlignment(Pos.CENTER);
		
		TextField choice8 = new TextField();
		choice8.setPromptText("Answer 8");
		
		ChoiceBox answer8 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox8 = new HBox(2);
		HBox8.getChildren().addAll(choice8, answer8);
		HBox8.setSpacing(10); 
		HBox8.setAlignment(Pos.CENTER);
		
		TextField choice9 = new TextField();
		choice9.setPromptText("Answer 9");
		
		ChoiceBox answer9 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox9 = new HBox(2);
		HBox9.getChildren().addAll(choice9, answer9);
		HBox9.setSpacing(10); 
		HBox9.setAlignment(Pos.CENTER);
		
		TextField choice10 = new TextField();
		choice10.setPromptText("Answer 10");
		
		ChoiceBox answer10 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox10 = new HBox(2);
		HBox10.getChildren().addAll(choice10, answer10);
		HBox10.setSpacing(10); 
		HBox10.setAlignment(Pos.CENTER);
		
		TextField choice11 = new TextField();
		choice11.setPromptText("Answer 11");
		
		ChoiceBox answer11 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox11 = new HBox(2);
		HBox11.getChildren().addAll(choice11, answer11);
		HBox11.setSpacing(10); 
		HBox11.setAlignment(Pos.CENTER);
		
		TextField choice12 = new TextField();
		choice12.setPromptText("Answer 12");
		
		ChoiceBox answer12 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox12 = new HBox(2);
		HBox12.getChildren().addAll(choice12, answer12);
		HBox12.setSpacing(10); 
		HBox12.setAlignment(Pos.CENTER);
		
		TextField choice13 = new TextField();
		choice13.setPromptText("Answer 13");
		
		ChoiceBox answer13 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox13 = new HBox(2);
		HBox13.getChildren().addAll(choice13, answer13);
		HBox13.setSpacing(10); 
		HBox13.setAlignment(Pos.CENTER);
		
		TextField choice14 = new TextField();
		choice14.setPromptText("Answer 14");
		
		ChoiceBox answer14 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox14 = new HBox(2);
		HBox14.getChildren().addAll(choice14, answer14);
		HBox14.setSpacing(10); 
		HBox14.setAlignment(Pos.CENTER);
		
		TextField choice15 = new TextField();
		choice15.setPromptText("Answer 15");
		
		ChoiceBox answer15 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox15 = new HBox(2);
		HBox15.getChildren().addAll(choice15, answer15);
		HBox15.setSpacing(10); 
		HBox15.setAlignment(Pos.CENTER);
		
		TextField choice16 = new TextField();
		choice16.setPromptText("Answer 16");
		
		ChoiceBox answer16 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox16 = new HBox(2);
		HBox16.getChildren().addAll(choice16, answer16);
		HBox16.setSpacing(10); 
		HBox16.setAlignment(Pos.CENTER);
		
		TextField choice17 = new TextField();
		choice17.setPromptText("Answer 17");
		
		ChoiceBox answer17 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox17 = new HBox(2);
		HBox17.getChildren().addAll(choice17, answer17);
		HBox17.setSpacing(10); 
		HBox17.setAlignment(Pos.CENTER);
		
		TextField choice18 = new TextField();
		choice18.setPromptText("Answer 18");
		
		ChoiceBox answer18 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox18 = new HBox(2);
		HBox18.getChildren().addAll(choice18, answer18);
		HBox18.setSpacing(10); 
		HBox18.setAlignment(Pos.CENTER);
		
		TextField choice19 = new TextField();
		choice19.setPromptText("Answer 19");
		
		ChoiceBox answer19 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox19 = new HBox(2);
		HBox19.getChildren().addAll(choice19, answer19);
		HBox19.setSpacing(10); 
		HBox19.setAlignment(Pos.CENTER);
		
		TextField choice20 = new TextField();
		choice20.setPromptText("Answer 20");
		
		ChoiceBox answer20 = new ChoiceBox(FXCollections.observableArrayList(
			    "Correct", "Incorrect"));
		
		HBox HBox20 = new HBox(2);
		HBox20.getChildren().addAll(choice20, answer20);
		HBox20.setSpacing(10); 
		HBox20.setAlignment(Pos.CENTER);
		
		//Create Question Button
		Button createQuestion = new Button("Create Question");
		createQuestion.setOnAction(e ->
		{
			//TODO - add question to database
			

			//TODO - add question to database
			Connection conn = null;
	        String sql;
	        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
	        // assign useUnicode and characterEncoding
	        
	        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
	        final String USER = "test";
	        final String PASSWORD = "123456";
	        
	        Date date = new Date();
		    SimpleDateFormat ft = new SimpleDateFormat ("yyyyMMddHHmmss");
	        
	        String[] temp = new String[4];
	        temp = course_Info_MA.split("\\|");
	        
	        String college_Name = temp[0];
	        String course_ID = temp[1];
	        String exam_Name = temp[3];
	        String question_ID = course_ID + exam_Name + ft.format(date);
	        String question_Text = questionText.getText();
	        String choice_Text = choice1.getText() + "|" + 
					   choice2.getText() + "|" + 
					   choice3.getText() + "|" + 
					   choice4.getText() + "|" + 
					   choice5.getText() + "|" + 
					   choice6.getText() + "|" + 
					   choice7.getText() + "|" + 
					   choice8.getText() + "|" + 
					   choice9.getText() + "|" + 
					   choice10.getText() + "|" + 
					   choice11.getText() + "|" + 
					   choice12.getText() + "|" + 
					   choice13.getText() + "|" + 
					   choice14.getText() + "|" + 
					   choice15.getText() + "|" + 
					   choice16.getText() + "|" + 
					   choice17.getText() + "|" + 
					   choice18.getText() + "|" + 
					   choice19.getText() + "|" + 
					   choice20.getText();

	        while(choice_Text.endsWith("|")) {
	        	choice_Text = choice_Text.substring(0, choice_Text.length()-2);
	        }
					   
	        String answer_Text = answer1.getValue() + "|" + 
		   			 	answer2.getValue() + "|" + 
		   			 	answer3.getValue() + "|" + 
		   			 	answer4.getValue() + "|" + 
		   			 	answer5.getValue() + "|" + 
		   			 	answer6.getValue() + "|" + 
		   			 	answer7.getValue() + "|" + 
		   			 	answer8.getValue() + "|" + 
		   			 	answer9.getValue() + "|" + 
		   			 	answer10.getValue() + "|" + 
		   			 	answer11.getValue() + "|" + 
		   			 	answer12.getValue() + "|" + 
		   			 	answer13.getValue() + "|" + 
		   			 	answer14.getValue() + "|" + 
		   			 	answer15.getValue() + "|" + 
		   			 	answer16.getValue() + "|" + 
		   			 	answer17.getValue() + "|" + 
		   			 	answer18.getValue() + "|" + 
		   			 	answer19.getValue() + "|" + 
		   			 	answer20.getValue();

	        while(answer_Text.endsWith("|")) {
	        	answer_Text = answer_Text.substring(0, answer_Text.length()-2);
	        	while(answer_Text.endsWith("null")) {
		        	answer_Text = answer_Text.substring(0, answer_Text.length()-5);
	        	}
	        }
	        
	        while(answer_Text.endsWith("null")) {
	        	answer_Text = answer_Text.substring(0, answer_Text.length()-5);
	        	while(answer_Text.endsWith("|")) {
		        	answer_Text = answer_Text.substring(0, answer_Text.length()-2);
	        	}
	        }
	        
	        int weight = 1;
	        try {
	        	weight = Integer.parseInt(weightText.getText());
	        } catch (Exception e1) {
	            e1.printStackTrace();
	            Alert alert = new Alert(AlertType.INFORMATION);
	            alert.setTitle("Wrong format!");
	            alert.setHeaderText(null);
	            alert.setContentText("Please input a correct format of number. Please reboot the program refresh the wrong cache.");

	            alert.showAndWait();
	            System.exit(0);
	        } 
	        
			try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("MySQL Driver is running successfully");
				conn = DriverManager.getConnection(URL, USER, PASSWORD);
				Statement stmt = conn.createStatement();
				
				sql = "insert into MA_Table(College_Name, Course_ID, Question_ID, Question_Text, Choice_Text, Answer_Text, Weight) values ('" + college_Name + "', '" + course_ID + "', '" + question_ID + "', '" + question_Text + "', '" + choice_Text + "', '" + answer_Text +  "', '" + weight + "')";//NOT DONE YET
				int result = stmt.executeUpdate(sql);// if return -1 then it crashed
		           if (result != -1) {
		               System.out.println("Successful execution!");
		               Alert alert = new Alert(AlertType.INFORMATION);
		               alert.setTitle("Successful execution!");
		               alert.setHeaderText(null);
		               alert.setContentText("You have created one record successfully! You can continue to create exams or close the window.");

		               alert.showAndWait();
		           }
			} catch (SQLException e1) {
	            System.out.println("MySQL executed unsuccessfully.");
	            e1.printStackTrace();
	        } catch (Exception e1) {
	            e1.printStackTrace();
	        } finally {
	        	try {
					conn.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
			
		
		});
		
		//Close Window
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		closeButton.setOnAction(e -> window.close());
		
		HBox functionHBox = new HBox(2);
		functionHBox.getChildren().addAll(createQuestion, closeButton);
		functionHBox.setPadding(new Insets(15, 12, 15, 12)); 
		functionHBox.setSpacing(10); 
		functionHBox.setAlignment(Pos.CENTER);
		
		//Layout
		VBox layout = new VBox(30);
		layout.getChildren().addAll(
					top, questionText, weightText, HBox1, HBox2, HBox3, HBox4, HBox5, HBox6, HBox7, HBox8, HBox9, HBox10, HBox11, HBox12, HBox13, HBox14, HBox15, HBox16, HBox17, HBox18, HBox19, HBox20, functionHBox
				);
		layout.setPadding(new Insets(5, 20, 5, 20));	
		layout.setSpacing(1);
		//Scene setup
		Scene scene = new Scene(layout);
		scene.getStylesheets().add("theme.css");
		window.setScene(scene);
		window.showAndWait();
		
		
	}
}
