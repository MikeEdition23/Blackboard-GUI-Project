//@author Terry Tan

import javafx.stage.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ReviewQuestions {
	
	public static void start()
	{
		//Window setup
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Review Questions");
		window.setMinWidth(1000);
		window.setMinHeight(600);
		
		//Creates drop down menu for courses
		TableView<Question> questionTable = new TableView<>();
		questionTable.setId("questionTable");
		questionTable.setStyle("-fx-text-base-color: #808080");
		questionTable.setStyle("");
		ObservableList<Question> data = FXCollections.observableArrayList();
		
		TableColumn collegeNameColumn = new TableColumn("College Name");
	    TableColumn courseIDColumn = new TableColumn("Course ID");
	    TableColumn questionIDColumn = new TableColumn("Question ID");
	    TableColumn questionTypeColumn = new TableColumn("Question Type");
	    TableColumn questionTextColumn = new TableColumn("Question Text");
	    TableColumn questionWeightColumn = new TableColumn("Weight");
	    TableColumn databaseTableColumn = new TableColumn("Database Table");
	    
	    questionTable.getColumns().addAll(collegeNameColumn, courseIDColumn, questionIDColumn, questionTypeColumn, questionTextColumn, questionWeightColumn, databaseTableColumn);
	    
	    collegeNameColumn.setMinWidth(50);
	    collegeNameColumn.setPrefWidth(105);
	    courseIDColumn.setMinWidth(50);
	    questionIDColumn.setMinWidth(50);
	    questionTypeColumn.setMinWidth(50);
	    questionTextColumn.setMinWidth(50);
	    questionWeightColumn.setMinWidth(50);
	    databaseTableColumn.setPrefWidth(120);
	    		
		Connection conn = null;
        String sql;
        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
        // assign useUnicode and characterEncoding
        
        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
        final String USER = "test";
        final String PASSWORD = "123456";
        
        String collegeName = "";
        String courseID = "";
        String questionID = "";
        String questionText = "";
        String weight = "";
        String questionType = "";
        String databaseTable = "";
        
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM MC_Table";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Multiple Choice", questionText, weight, "MC_Table"));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM ESS_Table";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Essay", questionText, weight, "ESS_Table"));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM FIB_Table";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Fill in the Blank", questionText, weight, "FIB_Table"));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM MA_Table";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Multiple Answer", questionText, weight, "MA_Table"));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM MQ_Table";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Matching Question", questionText, weight, "MQ_Table"));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM NR_Table";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Numeric Response", questionText, weight, "NR_Table"));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM OQ_Table";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Ordering Question", questionText, weight, "OQ_Table"));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM SR_Table";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Short Response", questionText, weight, "SR_Table"));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM TF_Table";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "True/False", questionText, weight, "TF_Table"));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM FR_Table";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "File Response", questionText, weight, "FR_Table"));
		      }
			
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		collegeNameColumn.setCellValueFactory(new PropertyValueFactory<>("collegeName"));
	    courseIDColumn.setCellValueFactory(new PropertyValueFactory<>("courseID"));
	    questionIDColumn.setCellValueFactory(new PropertyValueFactory<>("questionID"));
	    questionTypeColumn.setCellValueFactory(new PropertyValueFactory<>("questionType"));
	    questionTextColumn.setCellValueFactory(new PropertyValueFactory<>("questionText"));
	    questionWeightColumn.setCellValueFactory(new PropertyValueFactory<>("questionWeight"));
	    databaseTableColumn.setCellValueFactory(new PropertyValueFactory<>("databaseTable"));

		
	    questionTable.setItems(data);
	    
	    Label deleteLabel = new Label("Click the question you want to delete and then click the DELETE button and it will be deleted forever --->");
	    deleteLabel.setStyle("-fx-font-size: 12pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");
		Button deleteButton = new Button("Delete");
		deleteButton.setStyle("-fx-background-color: #FA8072;");
		deleteButton.setOnAction(e -> {
			System.out.println("select question");
			int selectedIndex = questionTable.getSelectionModel().getSelectedIndex();
	        if (selectedIndex >= 0) {
	        	
	        	String dbTable = questionTable.getItems().get(questionTable.getSelectionModel().getSelectedIndex()).getDatabaseTable();
	        	String qid = questionTable.getItems().get(questionTable.getSelectionModel().getSelectedIndex()).getQuestionID();
	        	delete(questionTable, dbTable, qid);
	            
	        } else {
	            // Nothing selected.
	        	//do not use the dialogs from the tutorial, use this http://blog.csdn.net/u010889616/article/details/53057047
	        	Alert alert = new Alert(AlertType.WARNING);
	        	alert.setTitle("No Selection");
	        	alert.setHeaderText("No Question Selected");
	        	alert.setContentText("Please select a question in the table!");

	        	alert.showAndWait();
	        	
	        }
		});
		
		HBox deleteHBox = new HBox(2);
		deleteHBox.getChildren().addAll(deleteLabel, deleteButton);
		deleteHBox.setPadding(new Insets(15, 12, 15, 12)); 
		deleteHBox.setSpacing(10); 
		deleteHBox.setAlignment(Pos.CENTER);

		
		//Print Button
		Button printQButton = new Button("Print Q Only");
		Button printQAButton = new Button("Print Q&A");
		Button printBBButton = new Button("Print BB Format");
		
		//Close Button
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		closeButton.setOnAction(e -> window.close());
		
		
		HBox functionHBox = new HBox(4);
		functionHBox.getChildren().addAll(closeButton);
		functionHBox.setPadding(new Insets(15, 12, 15, 12)); 
		functionHBox.setSpacing(10); 
		functionHBox.setAlignment(Pos.CENTER);
		
		Label block = new Label("");
		
		//Layout
		VBox layout = new VBox(10);
		layout.getChildren().addAll(
				questionTable, block, deleteHBox, functionHBox
				);
		layout.setPadding(new Insets(20, 20, 20, 20));
		layout.setAlignment(Pos.CENTER);
		//Scene setup
		Scene scene = new Scene(layout);
		scene.getStylesheets().add("theme.css");
		window.setScene(scene);
		window.showAndWait();
		
	}
	
	public static void delete(TableView table, String databaseTable, String qid) {
		
		final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
        final String USER = "test";
        final String PASSWORD = "123456";
        int selectedIndex = table.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            
			try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("MySQL Driver is running successfully");
				Connection deleteConn = DriverManager.getConnection(URL, USER, PASSWORD);
				Statement stmt = deleteConn.createStatement();
				
				String deleteSql = "DELETE FROM " + databaseTable + " WHERE Question_ID = '" + qid + "' ";
				int result = stmt.executeUpdate(deleteSql);// if return -1 then it crashed
		           if (result != -1) {
		               System.out.println("Successful execution!");
		               Alert alert = new Alert(AlertType.INFORMATION);
		               alert.setTitle("Successful deletion!");
		               alert.setHeaderText(null);
		               alert.setContentText("You have deleted one record successfully!");

		               alert.showAndWait();
		           }
		         deleteConn.close();
			} catch (SQLException e1) {
	            System.out.println("MySQL executed unsuccessfully.");
	            e1.printStackTrace();
	        } catch (Exception e1) {
	            e1.printStackTrace();
	        }
			table.getItems().remove(selectedIndex);
        } else {
            // Nothing selected.
        	//do not use the dialogs from the tutorial, use this http://blog.csdn.net/u010889616/article/details/53057047
        	Alert alert = new Alert(AlertType.WARNING);
        	alert.setTitle("No Selection");
        	alert.setHeaderText("No Question Selected");
        	alert.setContentText("Please select a question in the table!");

        	alert.showAndWait();
        	
        }
	}
	
	public static class Question {
		 
        SimpleStringProperty collegeName;
        SimpleStringProperty courseID;
        SimpleStringProperty questionID;
        SimpleStringProperty questionType;
        SimpleStringProperty questionText;
        SimpleStringProperty questionWeight;
        SimpleStringProperty databaseTable;
        
 
        Question(String cName, String cid, String qid, String qType, String qText, String weight, String dbTable) {
            this.collegeName = new SimpleStringProperty(cName);
            this.courseID = new SimpleStringProperty(cid);
            this.questionID = new SimpleStringProperty(qid);
            this.questionType = new SimpleStringProperty(qType);
            this.questionText = new SimpleStringProperty(qText);
            this.questionWeight = new SimpleStringProperty(weight);
            this.databaseTable = new SimpleStringProperty(dbTable);
        }
 
        public String getCollegeName() {
            return collegeName.get();
        }
 
        public void setCollegeName(String cName) {
            collegeName.set(cName);
        }
 
        public String getCourseID() {
            return courseID.get();
        }
 
        public void setCourseID(String cid) {
            courseID.set(cid);
        }
 
        public String getQuestionType() {
            return questionType.get();
        }
 
        public void setQuestionType(String qType) {
        	questionType.set(qType);
        }
        
        public String getQuestionText() {
            return questionText.get();
        }
 
        public void setQuestionText(String qText) {
        	questionText.set(qText);
        }
        
        public String getQuestionID() {
            return questionID.get();
        }
 
        public void setQuestionID(String qid) {
        	questionID.set(qid);
        }
        
        public String getQuestionWeight() {
            return questionWeight.get();
        }
 
        public void setQuestionWeight(String weight) {
        	questionWeight.set(weight);
        }
        
        public String getDatabaseTable() {
            return databaseTable.get();
        }
 
        public void setDatabaseTable(String dbTable) {
            databaseTable.set(dbTable);
        }
    }

}
