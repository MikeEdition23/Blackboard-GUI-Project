//@author David Stachnik

import javafx.stage.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

public class OrderQuestion 
{
	public static String course_Info_OQ = "";
	public static void start()
	{
		//Window setup 
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Multiple Answer");
		window.setMinWidth(500);
		window.setMinHeight(500);
				
		//Text
		Label top = new Label();
		top.setText("Enter Question Info. Enter answers in correct order, will be randomized when creating test.");
				
		//Text Fields for question info
		TextField questionText = new TextField();
		questionText.setPromptText("Question");
		
		TextField weightText = new TextField();
		weightText.setPromptText("Set the weight here. MUST be a number.");
		
		TextField answer1 = new TextField();
		answer1.setPromptText("Answer 1");
		
		TextField answer2 = new TextField();
		answer2.setPromptText("Answer 2");
		
		TextField answer3 = new TextField();
		answer3.setPromptText("Answer 3");
		
		TextField answer4 = new TextField();
		answer4.setPromptText("Answer 4");
		
		TextField answer5 = new TextField();
		answer5.setPromptText("Answer 5");
		
		TextField answer6 = new TextField();
		answer6.setPromptText("Answer 6");
		
		TextField answer7 = new TextField();
		answer7.setPromptText("Answer 7");
		
		TextField answer8 = new TextField();
		answer8.setPromptText("Answer 8");
		
		TextField answer9 = new TextField();
		answer9.setPromptText("Answer 9");
		
		TextField answer10 = new TextField();
		answer10.setPromptText("Answer 10");
		
		TextField answer11 = new TextField();
		answer11.setPromptText("Answer 11");
		
		TextField answer12 = new TextField();
		answer12.setPromptText("Answer 12");
		
		TextField answer13 = new TextField();
		answer13.setPromptText("Answer 13");
		
		TextField answer14 = new TextField();
		answer14.setPromptText("Answer 14");
		
		TextField answer15 = new TextField();
		answer15.setPromptText("Answer 15");
		
		TextField answer16 = new TextField();
		answer16.setPromptText("Answer 16");
		
		TextField answer17 = new TextField();
		answer17.setPromptText("Answer 17");
		
		TextField answer18 = new TextField();
		answer18.setPromptText("Answer 18");
		
		TextField answer19 = new TextField();
		answer19.setPromptText("Answer 19");
		
		TextField answer20 = new TextField();
		answer20.setPromptText("Answer 20");
				
		//Create Question Button
		Button createQuestion = new Button("Create Question");
		createQuestion.setOnAction(e ->
		{
			//TODO - add question to database

			//TODO - add question to database

			Connection conn = null;
	        String sql;
	        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
	        // assign useUnicode and characterEncoding
	        
	        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
	        final String USER = "test";
	        final String PASSWORD = "123456";
	        
	        Date date = new Date();
		    SimpleDateFormat ft = new SimpleDateFormat ("yyyyMMddHHmmss");
	        
	        String[] temp = new String[4];
	        temp = course_Info_OQ.split("\\|");
	        
	        String college_Name = temp[0];
	        String course_ID = temp[1];
	        String exam_Name = temp[3];
	        String question_ID = course_ID + exam_Name + ft.format(date);
	        String question_Text = questionText.getText();
	        String answer_Text = answer1.getText() + "|" + 
		   			 answer2.getText() + "|" + 
		   			 answer3.getText() + "|" + 
		   			 answer4.getText() + "|" + 
		   			 answer5.getText() + "|" + 
		   			 answer6.getText() + "|" + 
		   			 answer7.getText() + "|" + 
		   			 answer8.getText() + "|" + 
		   			 answer9.getText() + "|" + 
		   			 answer10.getText() + "|" + 
		   			 answer11.getText() + "|" + 
		   			 answer12.getText() + "|" + 
		   			 answer13.getText() + "|" + 
		   			 answer14.getText() + "|" + 
		   			 answer15.getText() + "|" + 
		   			 answer16.getText() + "|" + 
		   			 answer17.getText() + "|" + 
		   			 answer18.getText() + "|" + 
		   			 answer19.getText() + "|" + 
		   			 answer20.getText();

	        while(answer_Text.endsWith("|")) {
	        	answer_Text = answer_Text.substring(0, answer_Text.length()-1);
	        	while(answer_Text.endsWith("null")) {
		        	answer_Text = answer_Text.substring(0, answer_Text.length()-5);
	        	}
	        }
	        
	        while(answer_Text.endsWith("null")) {
	        	answer_Text = answer_Text.substring(0, answer_Text.length()-5);
	        	while(answer_Text.endsWith("|")) {
		        	answer_Text = answer_Text.substring(0, answer_Text.length()-1);
	        	}
	        }
	        
	        int weight = 1;
	        try {
	        	weight = Integer.parseInt(weightText.getText());
	        } catch (Exception e1) {
	            e1.printStackTrace();
	            Alert alert = new Alert(AlertType.INFORMATION);
	            alert.setTitle("Wrong format!");
	            alert.setHeaderText(null);
	            alert.setContentText("Please input a correct format of number. Please reboot the program refresh the wrong cache.");

	            alert.showAndWait();
	            System.exit(0);
	        }
	        
			try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("MySQL Driver is running successfully");
				conn = DriverManager.getConnection(URL, USER, PASSWORD);
				Statement stmt = conn.createStatement();
				
				sql = "insert into OQ_Table(College_Name, Course_ID, Question_ID, Question_Text, Answer_Text, Weight) values ('" + college_Name + "', '" + course_ID + "', '" + question_ID + "', '"+ question_Text + "', '" + answer_Text +  "', '" + weight + "')";//NOT DONE YET
				int result = stmt.executeUpdate(sql);// if return -1 then it crashed
		           if (result != -1) {
		               System.out.println("Successful execution!");
		               Alert alert = new Alert(AlertType.INFORMATION);
		               alert.setTitle("Successful execution!");
		               alert.setHeaderText(null);
		               alert.setContentText("You have created one record successfully! You can continue to create exams or close the window.");

		               alert.showAndWait();
		           }
			} catch (SQLException e1) {
	            System.out.println("MySQL executed unsuccessfully.");
	            e1.printStackTrace();
	        } catch (Exception e1) {
	            e1.printStackTrace();
	        } finally {
	        	try {
					conn.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
			
		});
				
		//Close Window
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		closeButton.setOnAction(e -> window.close());
		
		HBox functionHBox = new HBox(2);
		functionHBox.getChildren().addAll(createQuestion, closeButton);
		functionHBox.setPadding(new Insets(15, 12, 15, 12)); 
		functionHBox.setSpacing(10); 
		functionHBox.setAlignment(Pos.CENTER);
				
		//Layout
		VBox layout = new VBox(30);
		layout.getChildren().addAll(
				top, questionText, weightText, answer1, answer2, answer3, answer4, answer5, answer6, answer7, answer8, answer9, answer10, answer11, answer12, answer13, answer14, answer15, answer16, answer17, answer18, answer19, answer20,
				functionHBox
			);
		layout.setPadding(new Insets(5, 20, 5, 20));	
		layout.setSpacing(1);
		//Scene setup
		Scene scene = new Scene(layout);
		scene.getStylesheets().add("theme.css");
		window.setScene(scene);
		window.showAndWait();
	}
}
