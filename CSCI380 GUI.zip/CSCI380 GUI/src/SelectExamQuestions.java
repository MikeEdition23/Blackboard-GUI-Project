//@author Terry Tan

import javafx.stage.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.List;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;

public class SelectExamQuestions {
	public static String exam_Info = "";
	public static int count = 0;
	public static void start()
	{
		//Window setup
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Review Questions Based on Exam");
		window.setMinWidth(1000);
		window.setMinHeight(600);
		window.setHeight(1000);
		
		String[] temp = new String[8];
        temp = exam_Info.split("\\|");
        String college_Name = temp[0];
        String school_Name = temp[1];
        String course_ID = temp[2];
        String course_Name = temp[3];
        String semester = temp[4];
        String instructor_Name = temp[5];
        String instructor_Email = temp[6];
        String exam_Name = temp[7];
        String exam_Date = temp[8];
        
        TextField cnField = new TextField();
        cnField.setText(college_Name);
        TextField snField = new TextField();
        snField.setText(school_Name);
        TextField cidField = new TextField();
        cidField.setText(course_ID);
        TextField courseNameField = new TextField();
        courseNameField.setText(course_Name);
        TextField sField = new TextField();
        sField.setText(semester);
        TextField inField = new TextField();
        inField.setText(instructor_Name);
        TextField ieField = new TextField();
        ieField.setText(instructor_Email);
        TextField enField = new TextField();
        enField.setText(exam_Name);
        TextField edField = new TextField();
        edField.setText(exam_Date);
        
        int totalMark = 0;
        TextField questionNumField = new TextField();
        questionNumField.setText("0");
        
        Label selectedQuestionsLabel = new Label("Selected Questions: ");
        selectedQuestionsLabel.setStyle("-fx-font-size: 12pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");

        Label totalMarkLabel = new Label("Total Mark: ");
        totalMarkLabel.setStyle("-fx-font-size: 12pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");
        TextField totalMarkField = new TextField();
        HBox totalMarkHBox = new HBox(2);
		totalMarkHBox.getChildren().addAll(totalMarkLabel, totalMarkField);
		totalMarkHBox.setPadding(new Insets(15, 12, 15, 12)); 
		totalMarkHBox.setSpacing(10); 
		totalMarkHBox.setAlignment(Pos.CENTER);
		
		//Creates drop down menu for courses
		TableView<Question> questionTable = new TableView<>();
		questionTable.setId("questionTable");
		questionTable.setStyle("-fx-text-base-color: #808080");
		
		
		TableView<Question> selectedQuestionTable = new TableView<>();
		selectedQuestionTable.setId("selectedQuestionTable");
		selectedQuestionTable.setStyle("-fx-text-base-color: #808080");
		
		
		ObservableList<Question> data = FXCollections.observableArrayList();
		ObservableList<Question> selectedData = FXCollections.observableArrayList();

		
		TableColumn collegeNameColumn = new TableColumn("College Name");
	    TableColumn courseIDColumn = new TableColumn("Course ID");
	    TableColumn questionIDColumn = new TableColumn("Question ID");
	    TableColumn questionTypeColumn = new TableColumn("Question Type");
	    TableColumn questionTextColumn = new TableColumn("Question Text");
	    TableColumn choiceTextColumn = new TableColumn("Choice Text");
	    TableColumn answerTextColumn = new TableColumn("Answer Text");
	    TableColumn questionWeightColumn = new TableColumn("Weight");
	    TableColumn databaseTableColumn = new TableColumn("Database Table");
	    
	    TableColumn selectedCollegeNameColumn = new TableColumn("College Name");
	    TableColumn selectedCourseIDColumn = new TableColumn("Course ID");
	    TableColumn selectedQuestionIDColumn = new TableColumn("Question ID");
	    TableColumn selectedQuestionTypeColumn = new TableColumn("Question Type");
	    TableColumn selectedQuestionTextColumn = new TableColumn("Question Text");
	    TableColumn selectedChoiceTextColumn = new TableColumn("Choice Text");
	    TableColumn selectedAnswerTextColumn = new TableColumn("Answer Text");
	    TableColumn selectedQuestionWeightColumn = new TableColumn("Weight");
	    TableColumn selectedDatabaseTableColumn = new TableColumn("Database Table");
	    
	    questionTable.getColumns().addAll(collegeNameColumn, courseIDColumn, questionIDColumn, questionTypeColumn, questionTextColumn, questionWeightColumn, databaseTableColumn, choiceTextColumn, answerTextColumn);
	    selectedQuestionTable.getColumns().addAll(selectedCollegeNameColumn, selectedCourseIDColumn, selectedQuestionIDColumn, selectedQuestionTypeColumn, selectedQuestionTextColumn, selectedQuestionWeightColumn, selectedDatabaseTableColumn, selectedChoiceTextColumn, selectedAnswerTextColumn);
	    	    
	    collegeNameColumn.setPrefWidth(110);
	    courseIDColumn.setPrefWidth(100);
	    questionIDColumn.setPrefWidth(100);
	    questionTypeColumn.setPrefWidth(120);
	    questionTextColumn.setPrefWidth(120);
	    questionWeightColumn.setMinWidth(50);
	    databaseTableColumn.setPrefWidth(120);
	    choiceTextColumn.setVisible(false);
	    answerTextColumn.setVisible(false);
	    
	    selectedCollegeNameColumn.setPrefWidth(110);
	    selectedCourseIDColumn.setPrefWidth(100);
	    selectedQuestionIDColumn.setPrefWidth(100);
	    selectedQuestionTypeColumn.setPrefWidth(120);
	    selectedQuestionTextColumn.setPrefWidth(120);
	    selectedQuestionWeightColumn.setMinWidth(50);
	    selectedDatabaseTableColumn.setPrefWidth(120);
	    selectedChoiceTextColumn.setVisible(false);
	    selectedAnswerTextColumn.setVisible(false);
	    		
		Connection conn = null;
        String sql;
        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
        // assign useUnicode and characterEncoding
        
        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
        final String USER = "test";
        final String PASSWORD = "123456";
        
        String collegeName = "";
        String courseID = "";
        String questionID = "";
        String questionText = "";
        String choiceText = "";
        String answerText = "";
        String weight = "";
        String questionType = "";
        String databaseTable = "";
        
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight, Choice_Text, Answer_Text FROM MC_Table where College_Name='" + college_Name + "' and Course_ID='" + course_ID + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        choiceText = rs.getString("Choice_Text");
		        answerText = rs.getString("Answer_Text");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Multiple Choice", questionText, weight, "MC_Table", choiceText, answerText));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight, Answer_Text FROM ESS_Table where College_Name='" + college_Name + "' and Course_ID='" + course_ID + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        answerText = rs.getString("Answer_Text");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Essay", questionText, weight, "ESS_Table", "", answerText));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight, AnswerA_Text, AnswerB_Text FROM FIB_Table where College_Name='" + college_Name + "' and Course_ID='" + course_ID + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        answerText = rs.getString("AnswerA_Text") + "|" + rs.getString("AnswerB_Text");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Fill in the Blank", questionText, weight, "FIB_Table", "", answerText));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight, Choice_Text, Answer_Text FROM MA_Table where College_Name='" + college_Name + "' and Course_ID='" + course_ID + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        choiceText = rs.getString("Choice_Text");
		        answerText = rs.getString("Answer_Text");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Multiple Answer", questionText, weight, "MA_Table", choiceText, answerText));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight, Matching_Text, Answer_Text, Matching_Text FROM MQ_Table where College_Name='" + college_Name + "' and Course_ID='" + course_ID + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        choiceText = rs.getString("Matching_Text");
		        answerText = rs.getString("Answer_Text");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Matching Question", questionText, weight, "MQ_Table", choiceText, answerText));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight, Tolerance_Text, Answer_Text FROM NR_Table where College_Name='" + college_Name + "' and Course_ID='" + course_ID + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        choiceText = rs.getString("Tolerance_Text");
		        answerText = rs.getString("Answer_Text");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Numeric Response", questionText, weight, "NR_Table", choiceText, answerText));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight, Answer_Text FROM OQ_Table where College_Name='" + college_Name + "' and Course_ID='" + course_ID + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        answerText = rs.getString("Answer_Text");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Ordering Question", questionText, weight, "OQ_Table", "", answerText));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight, Answer_Text FROM SR_Table where College_Name='" + college_Name + "' and Course_ID='" + course_ID + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        answerText = rs.getString("Answer_Text");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "Short Response", questionText, weight, "SR_Table", "", answerText));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight, Answer_Text FROM TF_Table where College_Name='" + college_Name + "' and Course_ID='" + course_ID + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        answerText = rs.getString("Answer_Text");
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "True/False", questionText, weight, "TF_Table", "", answerText));
		      }
			
			sql = "select College_Name, Course_ID, Question_ID, Question_Text, Weight FROM FR_Table where College_Name='" + college_Name + "' and Course_ID='" + course_ID + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name

		        courseID = rs.getString("Course_ID");
		        collegeName = rs.getString("College_Name");
		        questionID = rs.getString("Question_ID");
		        questionText = rs.getString("Question_Text");
		        weight = "" + rs.getInt("Weight");
		        
		        
		        System.out.println(collegeName + " " + courseID);

		        data.add(new Question(collegeName, courseID, questionID, "File Response", questionText, weight, "FR_Table", "", ""));
		      }
			
			rs.close();
			totalMarkField.setText("" + totalMark);
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		collegeNameColumn.setCellValueFactory(new PropertyValueFactory<>("collegeName"));
	    courseIDColumn.setCellValueFactory(new PropertyValueFactory<>("courseID"));
	    questionIDColumn.setCellValueFactory(new PropertyValueFactory<>("questionID"));
	    questionTypeColumn.setCellValueFactory(new PropertyValueFactory<>("questionType"));
	    questionTextColumn.setCellValueFactory(new PropertyValueFactory<>("questionText"));
	    questionWeightColumn.setCellValueFactory(new PropertyValueFactory<>("questionWeight"));
	    databaseTableColumn.setCellValueFactory(new PropertyValueFactory<>("databaseTable"));
	    
	    selectedCollegeNameColumn.setCellValueFactory(new PropertyValueFactory<>("collegeName"));
	    selectedCourseIDColumn.setCellValueFactory(new PropertyValueFactory<>("courseID"));
	    selectedQuestionIDColumn.setCellValueFactory(new PropertyValueFactory<>("questionID"));
	    selectedQuestionTypeColumn.setCellValueFactory(new PropertyValueFactory<>("questionType"));
	    selectedQuestionTextColumn.setCellValueFactory(new PropertyValueFactory<>("questionText"));
	    selectedQuestionWeightColumn.setCellValueFactory(new PropertyValueFactory<>("questionWeight"));
	    selectedDatabaseTableColumn.setCellValueFactory(new PropertyValueFactory<>("databaseTable"));

	    questionTable.setItems(data);
	    selectedQuestionTable.setItems(selectedData);
	    
	    Label deleteLabel = new Label("Click the question you want to delete and then click the DELETE button --->");
	    deleteLabel.setStyle("-fx-font-size: 12pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");
		Button deleteButton = new Button("Delete");
		deleteButton.setStyle("-fx-background-color: #FA8072;");
		deleteButton.setOnAction(e -> {
			System.out.println("select question");
			int selectedIndex = selectedQuestionTable.getSelectionModel().getSelectedIndex();
	        if (selectedIndex >= 0) {
	        
	        	String tempWeight = selectedQuestionTable.getItems().get(selectedQuestionTable.getSelectionModel().getSelectedIndex()).getQuestionWeight();
	        	String totalMark1 = totalMarkField.getText();
	        	int totalMark2 = Integer.parseInt(totalMark1) - Integer.parseInt(tempWeight);
	        	totalMarkField.setText("" + totalMark2);
	        	
	        	selectedQuestionTable.getItems().remove(selectedIndex);
	        	int tempNum = Integer.parseInt(questionNumField.getText()) - 1;
	        	questionNumField.setText(tempNum + "");
	        } else {
	            // Nothing selected.
	        	//do not use the dialogs from the tutorial, use this http://blog.csdn.net/u010889616/article/details/53057047
	        	Alert alert = new Alert(AlertType.WARNING);
	        	alert.setTitle("No Selection");
	        	alert.setHeaderText("No Question Selected");
	        	alert.setContentText("Please select a question in the table!");

	        	alert.showAndWait();
	        	
	        }
		});
		
		HBox deleteHBox = new HBox(2);
		deleteHBox.getChildren().addAll(deleteLabel, deleteButton);
		deleteHBox.setPadding(new Insets(15, 12, 15, 12)); 
		deleteHBox.setSpacing(10); 
		deleteHBox.setAlignment(Pos.CENTER);
		
		Label addLabel = new Label("Click the question you want to add and then click the ADD button --->");
	    addLabel.setStyle("-fx-font-size: 12pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");
		Button addButton = new Button("   Add   ");
		addButton.setStyle("-fx-background-color: #98FB98;");
		addButton.setOnAction(e -> {
			System.out.println("add question");
			int selectedIndex = questionTable.getSelectionModel().getSelectedIndex();
	        if (selectedIndex >= 0) {
	        	
	        	String tempCollegeName = questionTable.getItems().get(selectedIndex).getCollegeName();
	    	    String tempCourseID = questionTable.getItems().get(selectedIndex).getCourseID();
	    	    String tempQuestionID = questionTable.getItems().get(selectedIndex).getQuestionID();
	    	    String tempQuestionType = questionTable.getItems().get(selectedIndex).getQuestionType();
	    	    String tempQuestionText = questionTable.getItems().get(selectedIndex).getQuestionText();
	    	    String tempDatabaseTable = questionTable.getItems().get(selectedIndex).getDatabaseTable();
	        	String tempWeight = questionTable.getItems().get(selectedIndex).getQuestionWeight();
	        	String tempChoiceText = questionTable.getItems().get(selectedIndex).getChoiceText();
	        	String tempAnswerText = questionTable.getItems().get(selectedIndex).getAnswerText();

	        	
	        	String totalMark1 = totalMarkField.getText();
	        	int totalMark2 = Integer.parseInt(totalMark1) + Integer.parseInt(tempWeight);
	        	totalMarkField.setText("" + totalMark2);
	        	
	        	int tempNum = Integer.parseInt(questionNumField.getText()) + 1;
	        	questionNumField.setText(tempNum + "");
	        	
	            selectedData.add(new Question(tempCollegeName, tempCourseID, tempQuestionID, tempQuestionType, tempQuestionText, tempWeight, tempDatabaseTable, tempChoiceText, tempAnswerText));
	        } else {
	            // Nothing selected.
	        	//do not use the dialogs from the tutorial, use this http://blog.csdn.net/u010889616/article/details/53057047
	        	Alert alert = new Alert(AlertType.WARNING);
	        	alert.setTitle("No Selection");
	        	alert.setHeaderText("No Question Selected");
	        	alert.setContentText("Please select a question in the table!");

	        	alert.showAndWait();
	        	
	        }
		});
		
		HBox addHBox = new HBox(2);
		addHBox.getChildren().addAll(addLabel, addButton);
		addHBox.setPadding(new Insets(15, 12, 15, 12)); 
		addHBox.setSpacing(10); 
		addHBox.setAlignment(Pos.CENTER);
		

		
		//Print Button
		Button printQButton = new Button("Print Q Only");
		printQButton.setOnAction(e -> {
			try {
				String userHomeFolder = System.getProperty("user.home");
				System.out.println(userHomeFolder);
				File writename = new File(userHomeFolder + "\\Desktop", cnField.getText() + "_" + cidField.getText() + "_" + sField.getText() + "_" + inField.getText() + "_" + enField.getText() + "_inClass.txt"); 
				BufferedWriter out = new BufferedWriter(new FileWriter(writename));  
				
				out.write(cnField.getText() + "\r\n" + snField.getText() + "\r\n" + cidField.getText() + "  " + courseNameField.getText() + "\r\n" + sField.getText() + "\r\n" + inField.getText() + "\r\n" + ieField.getText() + "\r\n" + enField.getText() + "\r\n" + edField.getText() + "\r\n \r\n");
				for(int i = 0, j = 1; i<Integer.parseInt(questionNumField.getText()); i++, j++) {
					
					String tempQuestionType = selectedQuestionTable.getItems().get(i).getQuestionType();
					String tempQuestionText = selectedQuestionTable.getItems().get(i).getQuestionText();
					String tempWeight = selectedQuestionTable.getItems().get(i).getQuestionWeight();
					String tempChoiceText = selectedQuestionTable.getItems().get(i).getChoiceText();
					String tempAnswerText = selectedQuestionTable.getItems().get(i).getAnswerText();

					if(tempQuestionType.equals("Multiple Choice")) {
						
						out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
						int length = stringNum(tempChoiceText);
						count = 0;
						String[] tempChoice = new String[length+1];
				        tempChoice = tempChoiceText.split("\\|");
				        String[] tempAnswer = new String[length+1];
				        tempAnswer = tempAnswerText.split("\\|");
				        
				        for(int i1 = 0; i1 <= length; i1++) {
				        	out.write((char)(65 + i1) + ") " + tempChoice[i1] + "\r\n");
				        }
				        out.write("\r\n\r\n");
				        
					}else if(tempQuestionType.equals("Essay")) {
						out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n\r\n");
						
					}else if(tempQuestionType.equals("Fill in the Blank")) {
						out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n\r\n");
						
					}else if(tempQuestionType.equals("Multiple Answer")) {
						out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
						int length = stringNum(tempChoiceText);
						count = 0;
						String[] tempChoice = new String[length+1];
				        tempChoice = tempChoiceText.split("\\|");
				        String[] tempAnswer = new String[length+1];
				        tempAnswer = tempAnswerText.split("\\|");
				        
				        for(int i1 = 0; i1 <= length; i1++) {
				        	out.write((char)(65 + i1) + ") " + tempChoice[i1] + "\r\n");
				        }
				        out.write("\r\n\r\n");
						
					}else if(tempQuestionType.equals("Matching Question")) {
						out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
						
						int length = stringNum(tempAnswerText);
						ArrayList<String> outputAnswer = new ArrayList<String>();
						count = 0;
						String[] tempAnswer = new String[length+1];
						String[] tempMatch = new String[length+1];

				        tempAnswer = tempAnswerText.split("\\|");
				        tempMatch = tempChoiceText.split("\\|");
				        for(int i1 = 0; i1 <= length; i1++) {
				        	tempAnswer[i1] = tempAnswer[i1] + (i1+1);
				        	outputAnswer.add(tempAnswer[i1]);
				        }
				        
				        Collections.shuffle(outputAnswer);
				        String[] answer = new String[length+1];
				        for(int i1 = 0; i1 <= length; i1++) {
				        	answer[i1] = outputAnswer.get(i1).substring(0, outputAnswer.get(i1).length()-1);
				        }
				        
				        for(int i1 = 0; i1 <= length; i1++) {
				        	out.write((i1+1) + ". " + tempMatch[i1] + "\t" + (char)(65+i1) + ") " +answer[i1] + "\r\n");
				        }
				        
				        out.write("\r\n\r\n");
						
					}else if(tempQuestionType.equals("Numeric Response")) {
						out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
					}else if(tempQuestionType.equals("Ordering Question")) {
						out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
						int length = stringNum(tempAnswerText);
						ArrayList<String> outputAnswer = new ArrayList<String>();
						count = 0;
						String[] tempAnswer = new String[length+1];
				        tempAnswer = tempAnswerText.split("\\|");
				        for(int i1 = 0; i1 <= length; i1++) {
				        	tempAnswer[i1] = tempAnswer[i1] + (i1+1);
				        	outputAnswer.add(tempAnswer[i1]);
				        }
				        
				        Collections.shuffle(outputAnswer);
				        String[] answer = new String[length+1];
				        for(int i1 = 0; i1 <= length; i1++) {
				        	answer[i1] = outputAnswer.get(i1).substring(0, outputAnswer.get(i1).length()-1);
				        }
				        
				        for(int i1 = 0; i1 <= length; i1++) {
				        	out.write((i1+1) + ". " + answer[i1] + "\r\n");
				        }
				        
				        out.write("\r\n\r\n");
				        
					}else if(tempQuestionType.equals("Short Response")) {
						out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
					}else if(tempQuestionType.equals("True/False")) {
						out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
					}else if(tempQuestionType.equals("File Response")) {
						out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n\r\n");	
					}
				
				}
				out.flush(); 
            	out.close();
            	System.out.println("Success!");
            	Alert alert = new Alert(AlertType.INFORMATION);
	               alert.setTitle("Successful!");
	               alert.setHeaderText(null);
	               alert.setContentText("You have created one file successfully on the desktop!");
	               alert.showAndWait();
			} catch (Exception e1) {
	            e1.printStackTrace();  
	        }
		});
		
		
		Button printQAButton = new Button("Print Q&A");
		printQAButton.setOnAction(e -> {
				try {
					String userHomeFolder = System.getProperty("user.home");
					System.out.println(userHomeFolder);
					File writename = new File(userHomeFolder + "\\Desktop", cnField.getText() + "_" + cidField.getText() + "_" + sField.getText() + "_" + inField.getText() + "_" + enField.getText() + "_inClass_withAnswer.txt"); 
					BufferedWriter out = new BufferedWriter(new FileWriter(writename));  
					
					out.write(cnField.getText() + "\r\n" + snField.getText() + "\r\n" + cidField.getText() + "  " + courseNameField.getText() + "\r\n" + sField.getText() + "\r\n" + inField.getText() + "\r\n" + ieField.getText() + "\r\n" + enField.getText() + "\r\n" + edField.getText() + "\r\n \r\n");
					for(int i = 0, j = 1; i<Integer.parseInt(questionNumField.getText()); i++, j++) {
						
						String tempQuestionType = selectedQuestionTable.getItems().get(i).getQuestionType();
						String tempQuestionText = selectedQuestionTable.getItems().get(i).getQuestionText();
						String tempWeight = selectedQuestionTable.getItems().get(i).getQuestionWeight();
						String tempChoiceText = selectedQuestionTable.getItems().get(i).getChoiceText();
						String tempAnswerText = selectedQuestionTable.getItems().get(i).getAnswerText();

						if(tempQuestionType.equals("Multiple Choice")) {
							
							out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
							int length = stringNum(tempChoiceText);
							count = 0;
							String[] tempChoice = new String[length+1];
					        tempChoice = tempChoiceText.split("\\|");
					        String[] tempAnswer = new String[length+1];
					        tempAnswer = tempAnswerText.split("\\|");
					        
					        for(int i1 = 0; i1 <= length; i1++) {
					        	if(tempAnswer[i1].equals("Correct")) {
					        		out.write((char)(65 + i1) + ") " + tempChoice[i1] + " ----**" + "\r\n");
					        	}else {
					        		out.write((char)(65 + i1) + ") " + tempChoice[i1] + "\r\n");
					        	}
					        }
					        out.write("\r\n\r\n");
					        
						}else if(tempQuestionType.equals("Essay")) {
							out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n");
							out.write(tempAnswerText + "\r\n\r\n\r\n");
							
						}else if(tempQuestionType.equals("Fill in the Blank")) {
							out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
							if(!tempAnswerText.endsWith("|")) {
								String[] temp1 = new String[2];
								temp1 = tempAnswerText.split("\\|");
								out.write("[A]: " + temp1[0] + " [B]: " + temp1[1] + "\r\n\r\n\r\n");
							}else {
								out.write("[A]: " + tempAnswerText.substring(0, tempAnswerText.length()-1) + "\r\n\r\n\r\n");
							}
							
						}else if(tempQuestionType.equals("Multiple Answer")) {
							out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
							int length = stringNum(tempChoiceText);
							count = 0;
							String[] tempChoice = new String[length+1];
					        tempChoice = tempChoiceText.split("\\|");
					        String[] tempAnswer = new String[length+1];
					        tempAnswer = tempAnswerText.split("\\|");
					        
					        for(int i1 = 0; i1 <= length; i1++) {
					        	if(tempAnswer[i1].equals("Correct")) {
					        		out.write((char)(65 + i1) + ") " + tempChoice[i1] + " ----**" + "\r\n");
					        	}else {
					        		out.write((char)(65 + i1) + ") " + tempChoice[i1] + "\r\n");
					        	}
					        }
					        out.write("\r\n\r\n");
							
						}else if(tempQuestionType.equals("Matching Question")) {
							out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
							
							int length = stringNum(tempAnswerText);
							ArrayList<String> outputAnswer = new ArrayList<String>();
							count = 0;
							String[] tempAnswer = new String[length+1];
							String[] tempMatch = new String[length+1];
							String finalAnswer = "";
					        tempAnswer = tempAnswerText.split("\\|");
					        tempMatch = tempChoiceText.split("\\|");
					        for(int i1 = 0; i1 <= length; i1++) {
					        	tempAnswer[i1] = tempAnswer[i1] + (i1+1);
					        	outputAnswer.add(tempAnswer[i1]);
					        }
					        
					        Collections.shuffle(outputAnswer);
					        String[] answer = new String[length+1];
					        for(int i1 = 0; i1 <= length; i1++) {
					        	answer[i1] = outputAnswer.get(i1).substring(0, outputAnswer.get(i1).length()-1);
					        }
					        
					        for(int i1 = 0; i1 <= length; i1++) {
					        	out.write((i1+1) + ". " + tempMatch[i1] + "\t" + (char)(65+i1) + ") " +answer[i1] + "\r\n");
					        	finalAnswer = finalAnswer + outputAnswer.get(i1).charAt(length+2) + "-" + (char)(65+i1) + " ";
					        }
					        
					        
					        out.write(finalAnswer);
					        out.write("\r\n\r\n\r\n");
							
						}else if(tempQuestionType.equals("Numeric Response")) {
							out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
							out.write(tempAnswerText + " Tolerance: " + tempChoiceText + "\r\n\r\n\r\n");
						}else if(tempQuestionType.equals("Ordering Question")) {//for less than 10 answers 
							out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
							int length = stringNum(tempAnswerText);//number of |
							ArrayList<String> outputAnswer = new ArrayList<String>();
							count = 0;
							String[] tempAnswer = new String[length+1];
							String finalAnswer = "";
							String[] numberArray = new String[length+1];
							int[] intArray = new int[length+1];
					        tempAnswer = tempAnswerText.split("\\|");
					        for(int i1 = 0; i1 <= length; i1++) {
					        	tempAnswer[i1] = tempAnswer[i1] + (i1+1);
					        	outputAnswer.add(tempAnswer[i1]);
					        	
					        }
					        
					        Collections.shuffle(outputAnswer);
					        String[] answer = new String[length+1];
					        for(int i1 = 0; i1 <= length; i1++) {
					        	numberArray[i1] = outputAnswer.get(i1).substring(outputAnswer.get(i1).length()-1, outputAnswer.get(i1).length()) + i1;
					        	answer[i1] = outputAnswer.get(i1).substring(0, outputAnswer.get(i1).length()-1);
					        	System.out.println(outputAnswer.get(i1));
					        	intArray[i1] = Integer.parseInt(numberArray[i1]);
					        }
					        Arrays.sort(intArray);
					        for(int i1 = 0; i1 <= length; i1++) {
					        	numberArray[i1] = intArray[i1] + "";
					        }
					        
					        for(int i1 = 0; i1 <= length; i1++) {
					        	out.write((i1+1) + ". " + answer[i1] + "\r\n");
					        	finalAnswer = finalAnswer + (Integer.parseInt(numberArray[i1].substring(numberArray[i1].length()-1))+1) + "-";
					        }
					        finalAnswer = finalAnswer.substring(0, finalAnswer.length()-1);
					        out.write(finalAnswer);
					        out.write("\r\n\r\n\r\n");
					        
						}else if(tempQuestionType.equals("Short Response")) {
							out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
							out.write(tempAnswerText + "\r\n\r\n\r\n");
						}else if(tempQuestionType.equals("True/False")) {
							out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
							out.write(tempAnswerText + "\r\n\r\n\r\n");
						}else if(tempQuestionType.equals("File Response")) {
							out.write("Q" + j + ": " + tempQuestionText + " " + "(" + tempWeight + " pts"+")" + "\r\n\r\n");
							out.write("// this was a file upload questions.\r\n\r\n\r\n");
						}
					
					}
					out.flush(); 
	            	out.close();
	            	System.out.println("Success!");
	            	Alert alert = new Alert(AlertType.INFORMATION);
		               alert.setTitle("Successful!");
		               alert.setHeaderText(null);
		               alert.setContentText("You have created one file successfully on the desktop!");
		               alert.showAndWait();
				} catch (Exception e1) {
		            e1.printStackTrace();  
		        }
		
			});
		
		
		Button printBBButton = new Button("Print BB Format");
		printBBButton.setOnAction(e -> {
			try {
				String userHomeFolder = System.getProperty("user.home");
				System.out.println(userHomeFolder);
				File writename = new File(userHomeFolder + "\\Desktop", cnField.getText() + "_" + cidField.getText() + "_" + sField.getText() + "_" + inField.getText() + "_" + enField.getText() + "_BB.txt"); 
				BufferedWriter out = new BufferedWriter(new FileWriter(writename));  
				
				for(int i = 0, j = 1; i<Integer.parseInt(questionNumField.getText()); i++, j++) {
					
					String tempQuestionType = selectedQuestionTable.getItems().get(i).getQuestionType();
					String tempQuestionText = selectedQuestionTable.getItems().get(i).getQuestionText();
					String tempWeight = selectedQuestionTable.getItems().get(i).getQuestionWeight();
					String tempChoiceText = selectedQuestionTable.getItems().get(i).getChoiceText();
					String tempAnswerText = selectedQuestionTable.getItems().get(i).getAnswerText();

					if(tempQuestionType.equals("Multiple Choice")) {
						
						out.write("MC" + "\t" + tempQuestionText + "\t");
						int length = stringNum(tempChoiceText);
						count = 0;
						String[] tempChoice = new String[length+1];
				        tempChoice = tempChoiceText.split("\\|");
				        String[] tempAnswer = new String[length+1];
				        tempAnswer = tempAnswerText.split("\\|");
				        
				        for(int i1 = 0; i1 <= length; i1++) {
				        	out.write(tempChoice[i1] + "\t" + tempAnswer[i1] + "\t");
				        }
				        out.write("\r\n");
				        
					}else if(tempQuestionType.equals("Essay")) {
						out.write("ESS" + "\t" + tempQuestionText + "\t" + tempAnswerText + "\r\n");
						
					}else if(tempQuestionType.equals("Fill in the Blank")) {
						out.write("FIB_PLUS" + "\t" + tempQuestionText + "\t");
						
						if(!tempAnswerText.endsWith("|")) {
							String[] temp1 = new String[2];
							temp1 = tempAnswerText.split("\\|");
							out.write("A\t" + temp1[0]+ "\t" + "B" + "\t" + temp1[1] + "\r\n");
						}else {
							out.write("A\t" + tempAnswerText.substring(0, tempAnswerText.length()-1) + "\r\n");
						}
						
					}else if(tempQuestionType.equals("Multiple Answer")) {
						out.write("MA" + "\t" + tempQuestionText + "\t");
						int length = stringNum(tempChoiceText);
						count = 0;
						String[] tempChoice = new String[length+1];
				        tempChoice = tempChoiceText.split("\\|");
				        String[] tempAnswer = new String[length+1];
				        tempAnswer = tempAnswerText.split("\\|");
				        
				        for(int i1 = 0; i1 <= length; i1++) {
				        	if(tempAnswer[i1].equals("Correct")) {
				        		out.write(tempChoice[i1] + "\tCorrect" + "\t");
				        	}else {
				        		out.write(tempChoice[i1] + "\tIncorrect" + "\t");
				        	}
				        }
						
					}else if(tempQuestionType.equals("Matching Question")) {
						out.write("MAT" + "\t" + tempQuestionText + "\t");
						
						int length = stringNum(tempAnswerText);
						ArrayList<String> outputAnswer = new ArrayList<String>();
						count = 0;
						String[] tempAnswer = new String[length+1];
						String[] tempMatch = new String[length+1];

				        tempAnswer = tempAnswerText.split("\\|");
				        tempMatch = tempChoiceText.split("\\|");
				        for(int i1 = 0; i1 <= length; i1++) {
				        	tempAnswer[i1] = tempAnswer[i1] + (i1+1);
				        	outputAnswer.add(tempAnswer[i1]);
				        }
				        
				        Collections.shuffle(outputAnswer);
				        String[] answer = new String[length+1];
				        for(int i1 = 0; i1 <= length; i1++) {
				        	answer[i1] = outputAnswer.get(i1).substring(0, outputAnswer.get(i1).length()-1);
				        }
				        
				        for(int i1 = 0; i1 <= length; i1++) {
				        	out.write(tempMatch[i1] + "\t" + answer[i1] + "\t");
				        }
				        
				        out.write("\r\n");
						
					}else if(tempQuestionType.equals("Numeric Response")) {
						out.write("NUM" + "\t" + tempQuestionText + "\t" + tempAnswerText + "\t"+ tempChoiceText + "\r\n");
					}else if(tempQuestionType.equals("Ordering Question")) {
						out.write("ORD" + "\t" + tempQuestionText + "\t");
						int length = stringNum(tempAnswerText);
						ArrayList<String> outputAnswer = new ArrayList<String>();
						count = 0;
						String[] tempAnswer = new String[length+1];
				        tempAnswer = tempAnswerText.split("\\|");
				        for(int i1 = 0; i1 <= length; i1++) {
				        	tempAnswer[i1] = tempAnswer[i1] + (i1+1);
				        	outputAnswer.add(tempAnswer[i1]);
				        }
				        
				        Collections.shuffle(outputAnswer);
				        String[] answer = new String[length+1];
				        for(int i1 = 0; i1 <= length; i1++) {
				        	answer[i1] = outputAnswer.get(i1).substring(0, outputAnswer.get(i1).length()-1);
				        }
				        
				        for(int i1 = 0; i1 <= length; i1++) {
				        	out.write(answer[i1] + "\t");
				        }
				        
				        out.write("\r\n");
				        
					}else if(tempQuestionType.equals("Short Response")) {
						out.write("SR" + "\t" + tempQuestionText + "\t" + tempAnswerText + "\r\n");
					}else if(tempQuestionType.equals("True/False")) {
						out.write("TF" + "\t" + tempQuestionText + "\t" + tempAnswerText + "\r\n");
					}else if(tempQuestionType.equals("File Response")) {
						out.write("FR" + "\t" + tempQuestionText + "\t" + tempAnswerText + "\r\n");			
					}
				
				}
				out.flush(); 
            	out.close();
            	System.out.println("Success!");
            	Alert alert = new Alert(AlertType.INFORMATION);
	               alert.setTitle("Successful!");
	               alert.setHeaderText(null);
	               alert.setContentText("You have created one file successfully on the desktop!");
	               alert.showAndWait();
			} catch (Exception e1) {
	            e1.printStackTrace();  
	        }
		});

		//Close Button
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		closeButton.setOnAction(e -> window.close());
		
		
		HBox functionHBox = new HBox(4);
		functionHBox.getChildren().addAll(printQButton, printQAButton, printBBButton, closeButton);
		functionHBox.setPadding(new Insets(15, 12, 15, 12)); 
		functionHBox.setSpacing(10); 
		functionHBox.setAlignment(Pos.CENTER);
		
		Label block = new Label("");
		
		//Layout
		VBox layout = new VBox(10);
		layout.getChildren().addAll(
				questionTable, selectedQuestionsLabel, selectedQuestionTable, totalMarkHBox, addHBox, deleteHBox, functionHBox
				);
		layout.setSpacing(10); 
		layout.setAlignment(Pos.CENTER);
		//Scene setup
		Scene scene = new Scene(layout);
		scene.getStylesheets().add("theme.css");
		window.setScene(scene);
		window.showAndWait();
		
	}
	
	public static void delete(TableView table, String databaseTable, String qid) {
		
		final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
        final String USER = "test";
        final String PASSWORD = "123456";
        int selectedIndex = table.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            
			try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("MySQL Driver is running successfully");
				Connection deleteConn = DriverManager.getConnection(URL, USER, PASSWORD);
				Statement stmt = deleteConn.createStatement();
				
				String deleteSql = "DELETE FROM " + databaseTable + " WHERE Question_ID = '" + qid + "' ";
				int result = stmt.executeUpdate(deleteSql);// if return -1 then it crashed
		           if (result != -1) {
		               System.out.println("Successful execution!");
		               Alert alert = new Alert(AlertType.INFORMATION);
		               alert.setTitle("Successful deletion!");
		               alert.setHeaderText(null);
		               alert.setContentText("You have deleted one record successfully!");

		               alert.showAndWait();
		           }
		         deleteConn.close();
			} catch (SQLException e1) {
	            System.out.println("MySQL executed unsuccessfully.");
	            e1.printStackTrace();
	        } catch (Exception e1) {
	            e1.printStackTrace();
	        }
			table.getItems().remove(selectedIndex);
        } else {
            // Nothing selected.
        	//do not use the dialogs from the tutorial, use this http://blog.csdn.net/u010889616/article/details/53057047
        	Alert alert = new Alert(AlertType.WARNING);
        	alert.setTitle("No Selection");
        	alert.setHeaderText("No Question Selected");
        	alert.setContentText("Please select a question in the table!");

        	alert.showAndWait();
        	
        }
	}
	
	public static class Question {
		 
        SimpleStringProperty collegeName;
        SimpleStringProperty courseID;
        SimpleStringProperty questionID;
        SimpleStringProperty questionType;
        SimpleStringProperty questionText;
        SimpleStringProperty questionWeight;
        SimpleStringProperty databaseTable;
        SimpleStringProperty choiceText;
        SimpleStringProperty answerText;
        
 
        Question(String cName, String cid, String qid, String qType, String qText, String weight, String dbTable, String cText, String aText) {
            this.collegeName = new SimpleStringProperty(cName);
            this.courseID = new SimpleStringProperty(cid);
            this.questionID = new SimpleStringProperty(qid);
            this.questionType = new SimpleStringProperty(qType);
            this.questionText = new SimpleStringProperty(qText);
            this.questionWeight = new SimpleStringProperty(weight);
            this.databaseTable = new SimpleStringProperty(dbTable);
            this.choiceText = new SimpleStringProperty(cText);
            this.answerText = new SimpleStringProperty(aText);
        }
 
        public String getCollegeName() {
            return collegeName.get();
        }
 
        public void setCollegeName(String cName) {
            collegeName.set(cName);
        }
 
        public String getCourseID() {
            return courseID.get();
        }
 
        public void setCourseID(String cid) {
            courseID.set(cid);
        }
 
        public String getQuestionType() {
            return questionType.get();
        }
 
        public void setQuestionType(String qType) {
        	questionType.set(qType);
        }
        
        public String getQuestionText() {
            return questionText.get();
        }
 
        public void setQuestionText(String qText) {
        	questionText.set(qText);
        }
        
        public String getQuestionID() {
            return questionID.get();
        }
 
        public void setQuestionID(String qid) {
        	questionID.set(qid);
        }
        
        public String getQuestionWeight() {
            return questionWeight.get();
        }
 
        public void setQuestionWeight(String weight) {
        	questionWeight.set(weight);
        }
        
        public String getDatabaseTable() {
            return databaseTable.get();
        }
 
        public void setDatabaseTable(String dbTable) {
            databaseTable.set(dbTable);
        }
        
        public String getChoiceText() {
            return choiceText.get();
        }
 
        public void setChoiceText(String cText) {
            choiceText.set(cText);
        }
        
        public String getAnswerText() {
            return answerText.get();
        }
 
        public void setAnswerText(String aText) {
            answerText.set(aText);
        }
    }
	
	public static int stringNum(String str) {
		
		if(str.indexOf("|")==-1) {
			return count;
		}else if(str.indexOf("|") != -1){
			count++;
			stringNum(str.substring(str.indexOf("|")+1));
			return count;
		}
		return 0;
	}

}
