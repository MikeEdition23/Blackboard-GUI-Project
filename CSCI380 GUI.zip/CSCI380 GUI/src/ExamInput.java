//@author Terry Tan

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Color;
import java.sql.Connection;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class ExamInput 
{
	public static void start()
	{
        
		//Window setup
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Exam Information");
		window.setMinWidth(500);
		window.setMinHeight(500);
		
		Connection conn = null;
        String sql;
        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
        // assign useUnicode and characterEncoding
        
        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
        final String USER = "test";
        final String PASSWORD = "123456";
        
        String courseID = "";
        String courseName = "";
        String collegeName = "";
        String examName = "";
        String schoolName = "";
		String departmentName = "";
		String instructorName = "";
		String semester = "";
        String year = "";
        String instructorEmail = "";
		
		//Text
		Label top = new Label();
		top.setText("Enter exam info into the fields below:");
		
		//Text Fields for Exam Information
		//-----------------------------------------------------------
		Label collegeNameLabel = new Label("College Name: ");
		ChoiceBox<String> collegeNameBox = new ChoiceBox<>();
		HBox collegeNameHBox = new HBox(2);
		collegeNameHBox.getChildren().addAll(collegeNameLabel, collegeNameBox);
		collegeNameHBox.setPadding(new Insets(15, 12, 15, 12)); 
		collegeNameHBox.setSpacing(10); 
		collegeNameHBox.setAlignment(Pos.CENTER_LEFT);
		try {
			ArrayList itemList = new ArrayList();
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			sql = "select College_Name FROM Course_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				OK:
				if(itemList.isEmpty()) {
					collegeName = rs.getString("College_Name");
					collegeNameBox.getItems().add(collegeName);
					itemList.add(collegeName);
				}else {
					collegeName = rs.getString("College_Name");
					for(int i = 0; i<itemList.size();i++) {
						if(itemList.get(i).equals(collegeName)){
							break OK;
						}else {
							continue;
						}
					}
					collegeNameBox.getItems().add(collegeName);
					itemList.add(collegeName);
				}
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		Label schoolNameLabel = new Label("School Name: ");
		ChoiceBox<String> schoolNameBox = new ChoiceBox<>();
		HBox schoolNameHBox = new HBox(2);
		schoolNameHBox.getChildren().addAll(schoolNameLabel, schoolNameBox);
		schoolNameHBox.setPadding(new Insets(15, 12, 15, 12)); 
		schoolNameHBox.setSpacing(10); 
		schoolNameHBox.setAlignment(Pos.CENTER_LEFT);
		try {
			ArrayList itemList = new ArrayList();
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			sql = "select School_Name FROM Course_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				OK:
				if(itemList.isEmpty()) {
					schoolName = rs.getString("School_Name");
					schoolNameBox.getItems().add(schoolName);
					itemList.add(schoolName);
				}else {
					schoolName = rs.getString("School_Name");
					for(int i = 0; i<itemList.size();i++) {
						if(itemList.get(i).equals(schoolName)){
							break OK;
						}else {
							continue;
						}
					}
					schoolNameBox.getItems().add(schoolName);
					itemList.add(schoolName);
				}
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		Label departmentNameLabel = new Label("Department Name: ");
		ChoiceBox<String> departmentNameBox = new ChoiceBox<>();
		HBox departmentNameHBox = new HBox(2);
		departmentNameHBox.getChildren().addAll(departmentNameLabel, departmentNameBox);
		departmentNameHBox.setPadding(new Insets(15, 12, 15, 12)); 
		departmentNameHBox.setSpacing(10); 
		departmentNameHBox.setAlignment(Pos.CENTER_LEFT);
		try {
			ArrayList itemList = new ArrayList();
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			sql = "select Depart_Name FROM Course_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				OK:
				if(itemList.isEmpty()) {
					departmentName = rs.getString("Depart_Name");
					departmentNameBox.getItems().add(departmentName);
					itemList.add(departmentName);
				}else {
					departmentName = rs.getString("Depart_Name");
					for(int i = 0; i<itemList.size();i++) {
						if(itemList.get(i).equals(departmentName)){
							break OK;
						}else {
							continue;
						}
					}
					departmentNameBox.getItems().add(departmentName);
					itemList.add(departmentName);
				}
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		Label courseIDLabel = new Label("Course ID: ");
		ChoiceBox<String> courseIDBox = new ChoiceBox<>();
		HBox courseIDHBox = new HBox(2);
		courseIDHBox.getChildren().addAll(courseIDLabel, courseIDBox);
		courseIDHBox.setPadding(new Insets(15, 12, 15, 12)); 
		courseIDHBox.setSpacing(10); 
		courseIDHBox.setAlignment(Pos.CENTER_LEFT);
		try {
			ArrayList itemList = new ArrayList();
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			sql = "select Course_ID FROM Course_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				OK:
				if(itemList.isEmpty()) {
					courseID = rs.getString("Course_ID");
					courseIDBox.getItems().add(courseID);
					itemList.add(courseID);
				}else {
					courseID = rs.getString("Course_ID");
					for(int i = 0; i<itemList.size();i++) {
						if(itemList.get(i).equals(courseID)){
							break OK;
						}else {
							continue;
						}
					}
					courseIDBox.getItems().add(courseID);
					itemList.add(courseID);
				}
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		Label courseNameLabel = new Label("Course Name: ");
		ChoiceBox<String> courseNameBox = new ChoiceBox<>();
		HBox courseNameHBox = new HBox(2);
		courseNameHBox.getChildren().addAll(courseNameLabel, courseNameBox);
		courseNameHBox.setPadding(new Insets(15, 12, 15, 12)); 
		courseNameHBox.setSpacing(10); 
		courseNameHBox.setAlignment(Pos.CENTER_LEFT);
		try {
			ArrayList itemList = new ArrayList();
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			sql = "select Course_Name FROM Course_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				OK:
				if(itemList.isEmpty()) {
					courseName = rs.getString("Course_Name");
					courseNameBox.getItems().add(courseName);
					itemList.add(courseName);
				}else {
					courseName = rs.getString("Course_Name");
					for(int i = 0; i<itemList.size();i++) {
						if(itemList.get(i).equals(courseName)){
							break OK;
						}else {
							continue;
						}
					}
					courseNameBox.getItems().add(courseName);
					itemList.add(courseName);
				}
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		Label examNameLabel = new Label("Exam Type: ");
		ChoiceBox<String> examNameBox = new ChoiceBox<>(FXCollections.observableArrayList(
			    "Quiz", "Midterm", "Final"));
		HBox examNameHBox = new HBox(2);
		examNameHBox.getChildren().addAll(examNameLabel, examNameBox);
		examNameHBox.setPadding(new Insets(15, 12, 15, 12)); 
		examNameHBox.setSpacing(10); 
		examNameHBox.setAlignment(Pos.CENTER_LEFT);
		
		Label examDate = new Label("Exam Date: ");
		DatePicker examDateField = new DatePicker(LocalDate.of(2017, 10, 8));
		examDateField.setShowWeekNumbers(true);
		examDateField.setStyle("-fx-text-base-color: #808080");
		
		HBox examDateHBox = new HBox(2);
		examDateHBox.getChildren().addAll(examDate, examDateField);
		examDateHBox.setPadding(new Insets(15, 12, 15, 12)); 
		examDateHBox.setSpacing(10); 
		examDateHBox.setAlignment(Pos.CENTER_LEFT);
		
		Label instructorNameLabel = new Label("Instructor Name: ");
		ChoiceBox<String> instructorNameBox = new ChoiceBox<>();
		HBox instructorNameHBox = new HBox(2);
		instructorNameHBox.getChildren().addAll(instructorNameLabel, instructorNameBox);
		instructorNameHBox.setPadding(new Insets(15, 12, 15, 12)); 
		instructorNameHBox.setSpacing(10); 
		instructorNameHBox.setAlignment(Pos.CENTER_LEFT);
		try {
			ArrayList itemList = new ArrayList();
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			sql = "select Instructor_Name FROM Course_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				OK:
				if(itemList.isEmpty()) {
					instructorName = rs.getString("Instructor_Name");
					instructorNameBox.getItems().add(instructorName);
					itemList.add(instructorName);
				}else {
					instructorName = rs.getString("Instructor_Name");
					for(int i = 0; i<itemList.size();i++) {
						if(itemList.get(i).equals(instructorName)){
							break OK;
						}else {
							continue;
						}
					}
					instructorNameBox.getItems().add(instructorName);
					itemList.add(instructorName);
				}
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		Label instructorEmailLabel = new Label("Instructor Email: ");
		ChoiceBox<String> instructorEmailBox = new ChoiceBox<>();
		HBox instructorEmailHBox = new HBox(2);
		instructorEmailHBox.getChildren().addAll(instructorEmailLabel, instructorEmailBox);
		instructorEmailHBox.setPadding(new Insets(15, 12, 15, 12)); 
		instructorEmailHBox.setSpacing(10); 
		instructorEmailHBox.setAlignment(Pos.CENTER_LEFT);
		try {
			ArrayList itemList = new ArrayList();
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			sql = "select Instructor_Email FROM Course_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				OK:
				if(itemList.isEmpty()) {
					instructorEmail = rs.getString("Instructor_Email");
					instructorEmailBox.getItems().add(instructorEmail);
					itemList.add(instructorEmail);
				}else {
					instructorEmail = rs.getString("Instructor_Email");
					for(int i = 0; i<itemList.size();i++) {
						if(itemList.get(i).equals(instructorEmail)){
							break OK;
						}else {
							continue;
						}
					}
					instructorEmailBox.getItems().add(instructorEmail);
					itemList.add(instructorEmail);
				}
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		Label semesterLabel = new Label("Semester: ");
		ChoiceBox<String> semesterBox = new ChoiceBox<>();
		HBox semesterHBox = new HBox(2);
		semesterHBox.getChildren().addAll(semesterLabel, semesterBox);
		semesterHBox.setPadding(new Insets(15, 12, 15, 12)); 
		semesterHBox.setSpacing(10); 
		semesterHBox.setAlignment(Pos.CENTER_LEFT);
		try {
			ArrayList itemList = new ArrayList();
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			sql = "select Semester FROM Course_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				OK:
				if(itemList.isEmpty()) {
					semester = rs.getString("Semester");
					semesterBox.getItems().add(semester);
					itemList.add(semester);
				}else {
					semester = rs.getString("Semester");
					for(int i = 0; i<itemList.size();i++) {
						if(itemList.get(i).equals(semester)){
							break OK;
						}else {
							continue;
						}
					}
					semesterBox.getItems().add(semester);
					itemList.add(semester);
				}
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		Label yearLabel = new Label("Year: ");
		ChoiceBox<String> yearBox = new ChoiceBox<>();
		HBox yearHBox = new HBox(2);
		yearHBox.getChildren().addAll(yearLabel, yearBox);
		yearHBox.setPadding(new Insets(15, 12, 15, 12)); 
		yearHBox.setSpacing(10); 
		yearHBox.setAlignment(Pos.CENTER_LEFT);
		try {
			ArrayList itemList = new ArrayList();
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			sql = "select Year FROM Course_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				OK:
				if(itemList.isEmpty()) {
					year = rs.getString("Year");
					yearBox.getItems().add(year);
					itemList.add(year);
				}else {
					year = rs.getString("Year");
					for(int i = 0; i<itemList.size();i++) {
						if(itemList.get(i).equals(year)){
							break OK;
						}else {
							continue;
						}
					}
					yearBox.getItems().add(year);
					itemList.add(year);
				}
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		//-----------------------------------------------------------
	
		//Create course button
		Button createExam = new Button("Create Exam");
		createExam.setOnAction(e -> 
		{
			if(Empty(collegeNameBox) || Empty(schoolNameBox) || Empty(departmentNameBox) || Empty(courseIDBox) ||
					Empty(courseNameBox) || Empty(examNameBox) || Empty(instructorNameBox) || Empty(semesterBox) || Empty(yearBox))
			{
				System.out.println("A field is not filled, try again"); // DEBUG
				Alert alert = new Alert(AlertType.WARNING);
	            alert.setTitle("Invalid Fields");
	            alert.setHeaderText(null);
	            alert.setContentText("Please correct invalid fields, including empty fields.");

	            alert.showAndWait();
			}
			else
			{
				System.out.println("All fields look good"); // DEBUG
				
		        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
		        // assign useUnicode and characterEncoding
		        
				//LOOK HERE MINGYAO!
				try {
					Class.forName("com.mysql.jdbc.Driver");
					System.out.println("MySQL Driver is running successfully");
					Connection insertConn = DriverManager.getConnection(URL, USER, PASSWORD);
					Statement stmt = insertConn.createStatement();
					
					String insertSql = "insert into Exam_Info(College_Name, School_Name, Depart_Name, Course_ID, Course_Name, Exam_Name,"
		            		+ "Exam_Date, Instructor_Name, Instructor_Email, Semester, Year) values ('" + collegeNameBox.getValue() + "', '" + schoolNameBox.getValue() + "', '" + departmentNameBox.getValue() + "', '" + courseIDBox.getValue() + "', '"
		            		+ courseNameBox.getValue() + "', '" + examNameBox.getValue() + "', '" + examDateField.getValue() + "', '" + instructorNameBox.getValue() + "', '"  + instructorEmailBox.getValue() + "', '" + semesterBox.getValue() + "', '" + yearBox.getValue() + "')";
					
					int result = stmt.executeUpdate(insertSql);// if return -1 then it crashed
			           if (result != -1) {
			               System.out.println("Successful execution!");
			               Alert alert = new Alert(AlertType.INFORMATION);
			               alert.setTitle("Successful execution!");
			               alert.setHeaderText(null);
			               alert.setContentText("You have created one record successfully! You can continue to create exams or close the window.");

			               alert.showAndWait();
			           }
			         insertConn.close();
				} catch (SQLException e1) {
		            System.out.println("MySQL executed unsuccessfully.");
		            e1.printStackTrace();
		        } catch (Exception e1) {
		            e1.printStackTrace();
		        }
				
			}
			
		});
		
		//Closes window
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		closeButton.setOnAction(e -> window.close());
		
		HBox functionHBox = new HBox(2);
		functionHBox.getChildren().addAll(createExam, closeButton);
		functionHBox.setPadding(new Insets(15, 12, 15, 12)); 
		functionHBox.setSpacing(10); 
		functionHBox.setAlignment(Pos.CENTER);
		
		//Layout
		VBox layout = new VBox(10);
		layout.getChildren().addAll(
				top,collegeNameHBox, schoolNameHBox, departmentNameHBox, courseIDHBox,
				courseNameHBox, examNameHBox, examDateHBox, instructorNameHBox, instructorEmailHBox, 
				semesterHBox, yearHBox, functionHBox
				);
		layout.setAlignment(Pos.CENTER);
		layout.setSpacing(5);
		//Scene setup
		Scene scene = new Scene(layout);
		scene.getStylesheets().add("theme.css");
		window.setScene(scene);
		window.showAndWait();
	
	}
	
	// Returns true if text field is not empty, false if empty
	private static boolean Empty(ChoiceBox input)
	{
		if(input.getValue().equals("null"))
		{
			System.out.println("Empty"); //DEBUG
			return true;
		}
		else
		{
			System.out.println("Not Empty"); //DEBUG
			return false;
		}
	}
	
	
	
	
	

}