//@author Terry Tan

import java.awt.Font;

import javafx.application.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Login extends Application 
{
	Stage window;
	Scene scene;
	
	public static void main(String[] args)
	{
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		//Set the window equal to primaryStage for easy naming
		window = primaryStage;
		
		window.setTitle("Login Window");
		
		//Code that run when user clicks X button on welcome window
		window.setOnCloseRequest(e -> 
		{
			//Prevents Close Request from automatically running
			e.consume();
			//Run closeProgram class
			closeProgram();
		});
		//Text
		Label label0 = new Label("Exam Generator");
		label0.setStyle("-fx-font-size: 20pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");
		
		Label usernameLabel = new Label("Username:  ");
		usernameLabel.setStyle("-fx-font-size: 11pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");
		TextField usernameTF = new TextField();
		Label passwordLabel = new Label("Password:  ");
		passwordLabel.setStyle("-fx-font-size: 11pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");
		PasswordField passwordPF = new PasswordField();
		
		//New Course Button
		Button OKButton = new Button("        OK        ");
		OKButton.setStyle("-fx-background-color: #98FB98;");
		OKButton.setOnAction(e -> 
		{	
			System.out.println("OK button clicked"); //DEBUG ONLY
			
			Connection conn = null;
	        String sql;
	        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
	        // assign useUnicode and characterEncoding
	        
	        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
	        final String USER = "test";
	        final String PASSWORD = "123456";
	        
	        Date date = new Date();
		    SimpleDateFormat ft = new SimpleDateFormat ("yyyyMMddHHmmss");
	        
	        String[] temp = new String[3];
	        
	        String usernameText = usernameTF.getText();
	        String passwordText = passwordPF.getText();
	        
			//LOOK HERE MINGYAO!
			try {
				String passwordReceived = "";
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("MySQL Driver is running successfully");
				conn = DriverManager.getConnection(URL, USER, PASSWORD);
				Statement stmt = conn.createStatement();
				
				sql = "select password FROM ACCOUNT_Table where username = '" + usernameText + "'";//NOT DONE YET
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next()){
					passwordReceived = rs.getString("password");
				}
				if(passwordReceived.equals(passwordText)) {
					try {
						Welcome.start();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}else {
					Alert alert = new Alert(AlertType.INFORMATION);
		               alert.setTitle("Wrong password!");
		               alert.setHeaderText(null);
		               alert.setContentText("You have to input the correct password or username. Try again!");

		               alert.showAndWait();
				}
			} catch (SQLException e1) {
	            System.out.println("MySQL executed unsuccessfully.");
	            e1.printStackTrace();
	            Alert alert = new Alert(AlertType.INFORMATION);
	               alert.setTitle("Wrong username!");
	               alert.setHeaderText(null);
	               alert.setContentText("No such username! Please input the correct one or create a new one.");

	               alert.showAndWait();
	        } catch (Exception e1) {
	            e1.printStackTrace();
	            
	        } finally {
	        	try {
					conn.close();
					window.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
			
		});
		
		Button CAButton = new Button("Create Account");
		CAButton.setOnAction(e -> 
		{	
			System.out.println("CA button clicked"); //DEBUG ONLY
			
			Connection conn = null;
	        String sql;
	        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
	        // assign useUnicode and characterEncoding
	        
	        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
	        final String USER = "test";
	        final String PASSWORD = "123456";
	        
	        Date date = new Date();
		    SimpleDateFormat ft = new SimpleDateFormat ("yyyyMMddHHmmss");
	        
	        String usernameText = usernameTF.getText();
	        String passwordText = passwordPF.getText();
	        
	        if(usernameText.equals("")||passwordText.equals("")) {
	        	Alert alert = new Alert(AlertType.INFORMATION);
	               alert.setTitle("Empty field!");
	               alert.setHeaderText(null);
	               alert.setContentText("Please fill in the empty fields! Try again.");

	               alert.showAndWait();
	               
	        }else {
	        
			try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("MySQL Driver is running successfully");
				conn = DriverManager.getConnection(URL, USER, PASSWORD);
				Statement stmt = conn.createStatement();
				
				sql = "insert into ACCOUNT_Table(username, password) values ('" + usernameText + "', '" + passwordText + "')";//NOT DONE YET
				int result = stmt.executeUpdate(sql);// if return -1 then it crashed
		           if (result != -1) {
		               System.out.println("Successful execution!");
		               Alert alert = new Alert(AlertType.INFORMATION);
		               alert.setTitle("Successful execution!");
		               alert.setHeaderText(null);
		               alert.setContentText("You have created an account successfully! You can click OK button to login.");

		               alert.showAndWait();
		           }
			} catch (SQLException e1) {
	            System.out.println("MySQL executed unsuccessfully.");
	            e1.printStackTrace();
	            System.out.println("Existed account!");
	               Alert alert = new Alert(AlertType.INFORMATION);
	               alert.setTitle("Existed account!");
	               alert.setHeaderText(null);
	               alert.setContentText("The account has exited! Login or try a new one.");

	               alert.showAndWait();
	        } catch (Exception e1) {
	            e1.printStackTrace();   
	        } finally {
	        	try {
					conn.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
	       }
		});
		
		//New Questions Button
		
		//Close Button
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		//Runs closeProgram Method when closeButton is pressed
		closeButton.setOnAction(e -> closeProgram());
		
		HBox usernameHBox = new HBox(2);
		usernameHBox.getChildren().addAll(usernameLabel, usernameTF);
		usernameHBox.setPadding(new Insets(15, 12, 15, 12)); 
		usernameHBox.setSpacing(10); 
		usernameHBox.setAlignment(Pos.CENTER);
		
		HBox passwordHBox = new HBox(2);
		passwordHBox.getChildren().addAll(passwordLabel, passwordPF);
		passwordHBox.setPadding(new Insets(15, 12, 15, 12)); 
		passwordHBox.setSpacing(10); 
		passwordHBox.setAlignment(Pos.CENTER);
		
		HBox OCHBox = new HBox(3);
		OCHBox.getChildren().addAll(CAButton, OKButton, closeButton);
		OCHBox.setPadding(new Insets(15, 12, 15, 12)); 
		OCHBox.setSpacing(10); 
		OCHBox.setAlignment(Pos.CENTER);
		
		//Layout Setup
		VBox layout1 = new VBox(4);
		layout1.getChildren().addAll(label0, usernameHBox, passwordHBox, OCHBox);
		layout1.setPadding(new Insets(20, 20, 20, 20));
		layout1.setAlignment(Pos.CENTER);
		scene = new Scene(layout1,500,200);
		scene.getStylesheets().add("theme.css");
		//Window setup
		window.setMinWidth(500);
		window.setMinHeight(300);
		window.setScene(scene);
		window.show();
		
	}
	
	//Class that should run before the program exits
	private void closeProgram()
	{
		System.out.println("Program Closing"); //DEBUG
		Platform.exit();
	}

}
