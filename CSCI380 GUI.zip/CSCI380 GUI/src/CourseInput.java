//@author David Stachnik

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class CourseInput 
{
	public static void start()
	{
        
		//Window setup
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Course Information");
		window.setMinWidth(500);
		window.setMinHeight(500);
		
		//Text
		Label top = new Label();
		top.setText("Enter course info into the fields below:");
		
		//Text Fields for Exam Information
		//-----------------------------------------------------------
		TextField collegeNameField = new TextField();
		collegeNameField.setPromptText("College Name");
		
		TextField schoolNameField = new TextField();
		schoolNameField.setPromptText("School Name");
		
		TextField departmentNameField = new TextField();
		departmentNameField.setPromptText("Department Name");
		
		TextField courseIDField = new TextField();
		courseIDField.setPromptText("Course ID");
		
		TextField courseNameField = new TextField();
		courseNameField.setPromptText("Course Name");
		
		TextField instructorNameField = new TextField();
		instructorNameField.setPromptText("Instructor Name");
		
		TextField instructorEmailField = new TextField();
		instructorEmailField.setPromptText("Instructor Email");
		
		TextField semesterField = new TextField();
		semesterField.setPromptText("Semester");
		
		TextField yearField = new TextField();
		yearField.setPromptText("Year");
		//-----------------------------------------------------------
	
		//Create course button
		Button createCourse = new Button("Create Course");
		createCourse.setOnAction(e -> 
		{
			if(Empty(collegeNameField) || Empty(schoolNameField) || Empty(departmentNameField) || Empty(courseIDField) ||
					Empty(courseNameField) || Empty(instructorNameField) || Empty(instructorEmailField) 
					|| Empty(semesterField) || Empty(yearField))
			{
				System.out.println("A field is not filled, try again"); // DEBUG
				Alert alert = new Alert(AlertType.WARNING);
	            alert.setTitle("Invalid Fields");
	            alert.setHeaderText(null);
	            alert.setContentText("Please correct invalid fields, including empty fields.");

	            alert.showAndWait();
			}
			else
			{
				System.out.println("All fields look good"); // DEBUG
				Connection conn = null;
		        String sql;
		        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
		        // assign useUnicode and characterEncoding
		        
		        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
		        final String USER = "test";
		        final String PASSWORD = "123456";
				
				//LOOK HERE MINGYAO!
				try {
					Class.forName("com.mysql.jdbc.Driver");
					System.out.println("MySQL Driver is running successfully");
					conn = DriverManager.getConnection(URL, USER, PASSWORD);
					Statement stmt = conn.createStatement();
					
					sql = "insert into Course_Info(College_Name, School_Name, Depart_Name, Course_ID, Course_Name,"
		            		+ "Instructor_Name, Instructor_Email, Semester, Year) values ('" + collegeNameField.getText() + "', '" + schoolNameField.getText() + "', '" + departmentNameField.getText() + "', '" + courseIDField.getText() + "', '"
		            		+ courseNameField.getText() + "', '" + instructorNameField.getText() + "', '" + instructorEmailField.getText() +"', '" + semesterField.getText() + "', '" + yearField.getText() + "')";
					
					int result = stmt.executeUpdate(sql);// if return -1 then it crashed
			           if (result != -1) {
			               System.out.println("Successful execution!");
			               Alert alert = new Alert(AlertType.INFORMATION);
			               alert.setTitle("Successful execution!");
			               alert.setHeaderText(null);
			               alert.setContentText("You have created one record successfully! You can continue to create exams or close the window.");

			               alert.showAndWait();
			           }
				} catch (SQLException e1) {
		            System.out.println("MySQL executed unsuccessfully.");
		            e1.printStackTrace();
		        } catch (Exception e1) {
		            e1.printStackTrace();
		        } finally {
		        	try {
						conn.close();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		        }
				
				
				
			}
			
		});
		
		//Closes window
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		closeButton.setOnAction(e -> window.close());
		
		HBox functionHBox = new HBox(2);
		functionHBox.getChildren().addAll(createCourse, closeButton);
		functionHBox.setPadding(new Insets(15, 12, 15, 12)); 
		functionHBox.setSpacing(10); 
		functionHBox.setAlignment(Pos.CENTER);
		
		//Layout
		VBox layout = new VBox(10);
		layout.getChildren().addAll(
				top,collegeNameField, schoolNameField, departmentNameField, courseIDField,
				courseNameField, instructorNameField, instructorEmailField, 
				semesterField, yearField, functionHBox
				);
		layout.setAlignment(Pos.CENTER);
		layout.setPadding(new Insets(20, 20, 20, 20));
		
		//Scene setup
		Scene scene = new Scene(layout);
		scene.getStylesheets().add("theme.css");
		window.setScene(scene);
		window.showAndWait();
	
	}
	
	// Returns true if text field is not empty, false if empty
	private static boolean Empty(TextField input)
	{
		if(input.getText().trim().isEmpty())
		{
			System.out.println("Empty"); //DEBUG
			return true;
		}
		else
		{
			System.out.println("Not Empty"); //DEBUG
			return false;
		}
	}
	
	
	
	
	

}