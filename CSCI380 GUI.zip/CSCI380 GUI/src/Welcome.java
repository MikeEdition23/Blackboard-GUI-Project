//@author Terry Tan

import javafx.application.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;

public class Welcome extends Application 
{

	public static void start() throws Exception {
		Stage window = new Stage();
		Scene scene;
		
		//Set the window equal to primaryStage for easy naming
		
		
		window.setTitle("Welcome to the Exam Builder");
		
		//Code that run when user clicks X button on welcome window
		window.setOnCloseRequest(e -> 
		{
			//Prevents Close Request from automatically running
			e.consume();
			//Run closeProgram class
			closeProgram();
		});
		//Text
		Label label1 = new Label("What would you like to do?");
		label1.setStyle("-fx-font-size: 20pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");
		
		//New Course Button
		Button newCourseButton = new Button("New Course");
		newCourseButton.setOnAction(e -> 
		{	
			System.out.println("New Course"); //DEBUG ONLY
			CourseInput.start();
		});
		
		//New Questions Button
		Button newQuestionsButton = new Button("New Question");
		newQuestionsButton.setOnAction(e ->
		{
			System.out.println("New Questions"); //DEBUG
			NewQuestions.start();
		});
		
		Button newExamButton = new Button("New Exam");
		newExamButton.setOnAction(e -> 
		{	
			System.out.println("New Exam"); //DEBUG ONLY
			ExamInput.start();
		});
		
		Button selectExamButton = new Button("Print Exam");
		selectExamButton.setOnAction(e ->
		{
			System.out.println("select exam");
			SelectExam.start();
		});
		
		Button selectCourseButton = new Button("Review Questions");
		selectCourseButton.setOnAction(e ->
		{
			System.out.println("select course");
			SelectCourse.start();
		});
		
		Button selectQuestionButton = new Button("Review Questions");
		selectQuestionButton.setOnAction(e ->
		{
			System.out.println("select question");
			ReviewQuestions.start();
		});
		
		//Close Button
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		//Runs closeProgram Method when closeButton is pressed
		closeButton.setOnAction(e -> closeProgram());
		
		HBox newHBox = new HBox(3);
		newHBox.getChildren().addAll(newCourseButton, newExamButton, newQuestionsButton);
		newHBox.setPadding(new Insets(15, 12, 15, 12)); 
		newHBox.setSpacing(24); 
		newHBox.setAlignment(Pos.CENTER);
		
		HBox selectHBox = new HBox(3);
		selectHBox.getChildren().addAll(selectCourseButton, selectExamButton);
		selectHBox.setPadding(new Insets(15, 12, 15, 12)); 
		selectHBox.setSpacing(24); 
		selectHBox.setAlignment(Pos.CENTER);
		
		//Layout Setup
		VBox layout1 = new VBox(20);
		layout1.getChildren().addAll(label1, newHBox, selectHBox, closeButton);
		layout1.setPadding(new Insets(10, 20, 10, 20));
		layout1.setAlignment(Pos.CENTER);
		scene = new Scene(layout1,600,350);
		scene.getStylesheets().add("theme.css");
		//Window setup
		window.setMinWidth(600);
		window.setMinHeight(350);
		window.setScene(scene);
		window.show();
		
	}
	
	//Class that should run before the program exits
	private static void closeProgram()
	{
		System.out.println("Program Closing"); //DEBUG
		Platform.exit();
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
