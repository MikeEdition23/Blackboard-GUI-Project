//@author Terry Tan

import javafx.stage.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;

public class SelectCourse {
	public static void start()
	{
		//Window setup
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("New Questions");
		window.setMinWidth(500);
		window.setMinHeight(300);
		
		//Creates drop down menu for courses
		ChoiceBox<String> courseBox = new ChoiceBox<>();
		
		Connection conn = null;
        String sql;
        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
        // assign useUnicode and characterEncoding
        
        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
        final String USER = "test";
        final String PASSWORD = "123456";
        
        String courseID = "";
        String courseName = "";
        String collegeName = "";
        
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			
			sql = "select College_Name, Course_ID, Course_Name FROM Course_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name
		         
		         courseID = rs.getString("Course_ID");
		         courseName = rs.getString("Course_Name");
		         collegeName = rs.getString("College_Name");
		         
		         
		         System.out.println(collegeName);
		         courseBox.getItems().add(collegeName + "|" + courseID + "|" + courseName);
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
				window.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		//Text
		Label top = new Label();
		top.setText("Select course below:");
		top.setStyle("-fx-font-size: 15pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");
		
		//Next Button
		Button nextButton = new Button("View Questions");
		nextButton.setStyle("-fx-background-color: #98FB98;");
		nextButton.setOnAction(e ->
		{	
			SelectCourseQuestions.course_Info = courseBox.getValue();
			SelectCourseQuestions.start();
		});
		
		//Close Button
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		closeButton.setOnAction(e -> window.close());
		
		
		HBox functionHBox = new HBox(2);
		functionHBox.getChildren().addAll(nextButton, closeButton);
		functionHBox.setPadding(new Insets(15, 12, 15, 12)); 
		functionHBox.setSpacing(10); 
		functionHBox.setAlignment(Pos.CENTER);
		
		Label block = new Label("");
		
		//Layout
		VBox layout = new VBox(10);
		layout.getChildren().addAll(
					top, courseBox, block, functionHBox
				);
		layout.setPadding(new Insets(20, 20, 20, 20));
		layout.setAlignment(Pos.CENTER);
		//Scene setup
		Scene scene = new Scene(layout);
		scene.getStylesheets().add("theme.css");
		window.setScene(scene);
		window.showAndWait();
		
	}

}
