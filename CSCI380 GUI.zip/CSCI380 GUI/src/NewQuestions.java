//@author David Stachnik

import javafx.stage.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;

public class NewQuestions {
	public static String course_Info = "";
	public static void start()
	{
		//Window setup
		//Terry Tan
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("New Questions");
		window.setMinWidth(500);
		window.setMinHeight(300);
		
		//Creates drop down menu for courses
		ChoiceBox<String> courseBox = new ChoiceBox<>();
		
		Connection conn = null;
        String sql;
        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
        // assign useUnicode and characterEncoding
        
        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
        final String USER = "test";
        final String PASSWORD = "123456";
        
        String courseID = "";
        String courseName = "";
        String collegeName = "";
        String examName = "";
        
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver is running successfully");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = conn.createStatement();
			
			sql = "select College_Name, Course_ID, Course_Name, Exam_Name FROM Exam_Info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
		         //Retrieve by column name
		         
		         courseID = rs.getString("Course_ID");
		         courseName = rs.getString("Course_Name");
		         collegeName = rs.getString("College_Name");
		         examName = rs.getString("Exam_Name");
		         
		         System.out.println(collegeName + " " + examName);
		         courseBox.getItems().add(collegeName + "|" + courseID + "|" + courseName + "|" + examName);
		      }
			rs.close();
		} catch (SQLException e1) {
            System.out.println("MySQL executed unsuccessfully.");
            e1.printStackTrace();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
        	try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
		
		//Text
		Label top = new Label();
		top.setText("Select course and question type below:");
		top.setStyle("-fx-font-size: 15pt; -fx-font-family: 'Segoe UI Semibold'; -fx-text-fill: white;");
		
		
		//Drop down menu for question types
		ChoiceBox<String> questionBox = new ChoiceBox<>();
		questionBox.setStyle("-fx-text-fill: #404040;");
		
		//Add items to questionBox
		questionBox.getItems().addAll("Multiple Choice", "Multiple Answer", "True/False", "Essay", "Order Question", "Match Question",
				"File Response", "Numeric Response", "Short Response", "Fill in the Blank");
		
		//New Course Button
		Button newExamButton = new Button("Enter New Course Info");
		newExamButton.setOnAction(e ->
		{
			System.out.println("New Course"); //DEBUG ONLY
			CourseInput.start();
		});
		
		//Next Button
		Button nextButton = new Button("Next");
		nextButton.setOnAction(e ->
		{
			course_Info = courseBox.getValue();
			//System.out.println(course_Info);
			if(questionBox.getValue() == "Multiple Choice"){
				System.out.println("Multiple Choice Window Opening"); //Debug
				MultipleChoice.course_Info_MC = course_Info;
				MultipleChoice.start();
			}else if(questionBox.getValue() == "True/False"){
				System.out.println("True/False Window Opening"); //Debug
				TrueFalse.course_Info_TF = course_Info;
				TrueFalse.start();
			}else if(questionBox.getValue() == "Numeric Response") {
				System.out.println("Numeric Response Window Opening"); //Debug
				NumericResponse.course_Info_NR = course_Info;
				NumericResponse.start();
			}else if(questionBox.getValue() == "Order Question") {
				System.out.println("Order Question Window Opening"); //Debug
				OrderQuestion.course_Info_OQ = course_Info;
				OrderQuestion.start();
			}else if(questionBox.getValue() == "Short Response") {
				System.out.println("Short Response Window Opening"); //Debug
				ShortResponse.course_Info_SR = course_Info;
				ShortResponse.start();
			}else if(questionBox.getValue() == "Multiple Answer") {
				System.out.println("Short Response Window Opening"); //Debug
				MultipleAnswer.course_Info_MA = course_Info;
				MultipleAnswer.start();
			}else if(questionBox.getValue() == "Essay") {
				System.out.println("Essay Window Opening"); //Debug
				Essay.course_Info_ESS = course_Info;
				Essay.start();
			}else if(questionBox.getValue() == "Match Question"){
				System.out.println("Match Question Window Opening"); //Debug
				MatchingQuestion.course_Info_MQ = course_Info;
				MatchingQuestion.start();
			}else if(questionBox.getValue() == "Fill in the Blank"){
				System.out.println("Fill in the Blank Window Opening"); //Debug
				FillInTheBlank.course_Info_FB = course_Info;
				FillInTheBlank.start();
			}else if(questionBox.getValue() == "File Response"){
				System.out.println("File Response Window Opening"); //Debug
				FileResponse.course_Info_FR = course_Info;
				FileResponse.start();
			}
		});
		
		//Close Button
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		closeButton.setOnAction(e -> window.close());
		
		
		HBox functionHBox = new HBox(2);
		functionHBox.getChildren().addAll(nextButton, closeButton);
		functionHBox.setPadding(new Insets(15, 12, 15, 12)); 
		functionHBox.setSpacing(10); 
		functionHBox.setAlignment(Pos.CENTER);
		
		Label block = new Label("");
		
		//Layout
		VBox layout = new VBox(10);
		layout.getChildren().addAll(
					top, courseBox, questionBox, block, newExamButton, functionHBox
				);
		layout.setPadding(new Insets(20, 20, 20, 20));
		layout.setAlignment(Pos.CENTER);
		//Scene setup
		Scene scene = new Scene(layout);
		scene.getStylesheets().add("theme.css");
		window.setScene(scene);
		window.showAndWait();
		
	}

}
