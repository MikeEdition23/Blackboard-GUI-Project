//@author Terry Tan

import javafx.stage.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

public class FileResponse 
{
	public static String course_Info_FR = "";
	public static void start()
	{
		//Window setup 
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("File Response Question");
		window.setMinWidth(500);
		window.setMinHeight(500);
		
		//Text
		Label top = new Label();
		top.setText("Enter Question Info");
		
		//Text Fields for question info
		TextField questionText = new TextField();
		questionText.setPromptText("Question");
		
		TextField weightText = new TextField();
		weightText.setPromptText("Set the weight here. MUST be a number.");
		
		//Create Question Button
		Button createQuestion = new Button("Create Question");
		createQuestion.setOnAction(e ->
		{
			//TODO - add question to database

			//TODO - add question to database
			Connection conn = null;
	        String sql;
	        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
	        // assign useUnicode and characterEncoding
	        
	        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
	        final String USER = "test";
	        final String PASSWORD = "123456";
	        
	        Date date = new Date();
		    SimpleDateFormat ft = new SimpleDateFormat ("yyyyMMddHHmmss");
	        
	        String[] temp = new String[4];
	        temp = course_Info_FR.split("\\|");
	        
	        String college_Name = temp[0];
	        String course_ID = temp[1];
	        String exam_Name = temp[3];
	        String question_ID = course_ID + exam_Name + ft.format(date);
	        String question_Text = questionText.getText();
	        int weight = 1;
	        try {
	        	weight = Integer.parseInt(weightText.getText());
	        } catch (Exception e1) {
	            e1.printStackTrace();
	            Alert alert = new Alert(AlertType.INFORMATION);
	            alert.setTitle("Wrong format!");
	            alert.setHeaderText(null);
	            alert.setContentText("Please input a correct format of number. Please reboot the program refresh the wrong cache.");

	            alert.showAndWait();
	            System.exit(0);
	        } 
	        
			try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("MySQL Driver is running successfully");
				conn = DriverManager.getConnection(URL, USER, PASSWORD);
				Statement stmt = conn.createStatement();
				
				sql = "insert into FR_Table(College_Name, Course_ID, Question_ID, Question_Text, Weight) values ('" + college_Name + "', '" + course_ID + "', '" + question_ID + "', '" + question_Text + "', '"+ weight + "')";//NOT DONE YET
				int result = stmt.executeUpdate(sql);// if return -1 then it crashed
		           if (result != -1) {
		               System.out.println("Successful execution!");
		               Alert alert = new Alert(AlertType.INFORMATION);
		               alert.setTitle("Successful execution!");
		               alert.setHeaderText(null);
		               alert.setContentText("You have created one record successfully! You can continue to create exams or close the window.");

		               alert.showAndWait();
		           }
			} catch (SQLException e1) {
	            System.out.println("MySQL executed unsuccessfully.");
	            e1.printStackTrace();
	        } catch (Exception e1) {
	            e1.printStackTrace();
	        } finally {
	        	try {
					conn.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
			
		});
						
		//Close Window
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		closeButton.setOnAction(e -> window.close());
		
		HBox functionHBox = new HBox(2);
		functionHBox.getChildren().addAll(createQuestion, closeButton);
		functionHBox.setPadding(new Insets(15, 12, 15, 12));
		functionHBox.setSpacing(10); 
		functionHBox.setAlignment(Pos.CENTER);
						
		//Layout
		VBox layout = new VBox(10);
		layout.getChildren().addAll(
					top, questionText, weightText, 
					functionHBox
				);
		layout.setPadding(new Insets(20, 20, 20, 20));				
		//Scene setup
		Scene scene = new Scene(layout);
		scene.getStylesheets().add("theme.css");
		window.setScene(scene);
		window.showAndWait();
	}
}