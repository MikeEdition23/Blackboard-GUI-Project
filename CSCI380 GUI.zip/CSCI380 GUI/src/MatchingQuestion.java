import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

//@author David Stachnik

public class MatchingQuestion 
{
	public static String course_Info_MQ = "";
	public static void start()
	{
		//Window setup
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Matching Question");
		window.setMinWidth(500);
		window.setMinHeight(500);
		
		//Text 
		Label top = new Label();
		top.setText("Enter Question Info (Answers will be randomised on the student's test):");
		
		//Text Fields for question info
		TextField questionText = new TextField();
		questionText.setPromptText("Question");
		
		TextField weightText = new TextField();
		weightText.setPromptText("Set the weight here. MUST be a number.");
		
		TextField match1 = new TextField();
		match1.setPromptText("Match 1");
		
		TextField answer1 = new TextField();
		answer1.setPromptText("Answer 1");
		
		HBox HBox1 = new HBox(2);
		HBox1.getChildren().addAll(match1, answer1);
		HBox1.setSpacing(10); 
		HBox1.setAlignment(Pos.CENTER);
		
		TextField match2 = new TextField();
		match2.setPromptText("Match 2");
		
		TextField answer2 = new TextField();
		answer2.setPromptText("Answer 2");
		
		HBox HBox2 = new HBox(2);
		HBox2.getChildren().addAll(match2, answer2);
		HBox2.setSpacing(10); 
		HBox2.setAlignment(Pos.CENTER);
		
		TextField match3 = new TextField();
		match3.setPromptText("Match 3");
		
		TextField answer3 = new TextField();
		answer3.setPromptText("Answer 3");
		
		HBox HBox3 = new HBox(2);
		HBox3.getChildren().addAll(match3, answer3);
		HBox3.setSpacing(10); 
		HBox3.setAlignment(Pos.CENTER);
		
		TextField match4 = new TextField();
		match4.setPromptText("Match 4");
		
		TextField answer4 = new TextField();
		answer4.setPromptText("Answer 4");
		
		HBox HBox4 = new HBox(2);
		HBox4.getChildren().addAll(match4, answer4);
		HBox4.setSpacing(10); 
		HBox4.setAlignment(Pos.CENTER);
		
		TextField match5 = new TextField();
		match5.setPromptText("Match 5");
		
		TextField answer5 = new TextField();
		answer5.setPromptText("Answer 5");
		
		HBox HBox5 = new HBox(2);
		HBox5.getChildren().addAll(match5, answer5);
		HBox5.setSpacing(10); 
		HBox5.setAlignment(Pos.CENTER);
		
		TextField match6 = new TextField();
		match6.setPromptText("Match 6");
		
		TextField answer6 = new TextField();
		answer6.setPromptText("Answer 6");
		
		HBox HBox6 = new HBox(2);
		HBox6.getChildren().addAll(match6, answer6);
		HBox6.setSpacing(10); 
		HBox6.setAlignment(Pos.CENTER);
		
		TextField match7 = new TextField();
		match7.setPromptText("Match 7");
		
		TextField answer7 = new TextField();
		answer7.setPromptText("Answer 7");
		
		HBox HBox7 = new HBox(2);
		HBox7.getChildren().addAll(match7, answer7);
		HBox7.setSpacing(10); 
		HBox7.setAlignment(Pos.CENTER);
		
		TextField match8 = new TextField();
		match8.setPromptText("Match 8");
		
		TextField answer8 = new TextField();
		answer8.setPromptText("Answer 8");
		
		HBox HBox8 = new HBox(2);
		HBox8.getChildren().addAll(match8, answer8);
		HBox8.setSpacing(10); 
		HBox8.setAlignment(Pos.CENTER);
		
		TextField match9 = new TextField();
		match9.setPromptText("Match 9");
		
		TextField answer9 = new TextField();
		answer9.setPromptText("Answer 9");
		
		HBox HBox9 = new HBox(2);
		HBox9.getChildren().addAll(match9, answer9);
		HBox9.setSpacing(10); 
		HBox9.setAlignment(Pos.CENTER);
		
		TextField match10 = new TextField();
		match10.setPromptText("Match 10");
		
		TextField answer10 = new TextField();
		answer10.setPromptText("Answer 10");
		
		HBox HBox10 = new HBox(2);
		HBox10.getChildren().addAll(match10, answer10);
		HBox10.setSpacing(10); 
		HBox10.setAlignment(Pos.CENTER);
		
		TextField match11 = new TextField();
		match11.setPromptText("Match 11");
		
		TextField answer11 = new TextField();
		answer11.setPromptText("Answer 11");
		
		HBox HBox11 = new HBox(2);
		HBox11.getChildren().addAll(match11, answer11);
		HBox11.setSpacing(10); 
		HBox11.setAlignment(Pos.CENTER);
		
		TextField match12 = new TextField();
		match12.setPromptText("Match 12");
		
		TextField answer12 = new TextField();
		answer12.setPromptText("Answer 12");
		
		HBox HBox12 = new HBox(2);
		HBox12.getChildren().addAll(match12, answer12);
		HBox12.setSpacing(10); 
		HBox12.setAlignment(Pos.CENTER);
		
		TextField match13 = new TextField();
		match13.setPromptText("Match 13");
		
		TextField answer13 = new TextField();
		answer13.setPromptText("Answer 13");
		
		HBox HBox13 = new HBox(2);
		HBox13.getChildren().addAll(match13, answer13);
		HBox13.setSpacing(10); 
		HBox13.setAlignment(Pos.CENTER);
		
		TextField match14 = new TextField();
		match14.setPromptText("Match 14");
		
		TextField answer14 = new TextField();
		answer14.setPromptText("Answer 14");
		
		HBox HBox14 = new HBox(2);
		HBox14.getChildren().addAll(match14, answer14);
		HBox14.setSpacing(10); 
		HBox14.setAlignment(Pos.CENTER);
		
		TextField match15 = new TextField();
		match15.setPromptText("Match 15");
		
		TextField answer15 = new TextField();
		answer15.setPromptText("Answer 15");
		
		HBox HBox15 = new HBox(2);
		HBox15.getChildren().addAll(match15, answer15);
		HBox15.setSpacing(10); 
		HBox15.setAlignment(Pos.CENTER);
		
		TextField match16 = new TextField();
		match16.setPromptText("Match 16");
		
		TextField answer16 = new TextField();
		answer16.setPromptText("Answer 16");
		
		HBox HBox16 = new HBox(2);
		HBox16.getChildren().addAll(match16, answer16);
		HBox16.setSpacing(10); 
		HBox16.setAlignment(Pos.CENTER);
		
		TextField match17 = new TextField();
		match17.setPromptText("Match 17");
		
		TextField answer17 = new TextField();
		answer17.setPromptText("Answer 17");
		
		HBox HBox17 = new HBox(2);
		HBox17.getChildren().addAll(match17, answer17);
		HBox17.setSpacing(10); 
		HBox17.setAlignment(Pos.CENTER);
		
		TextField match18 = new TextField();
		match18.setPromptText("Match 18");
		
		TextField answer18 = new TextField();
		answer18.setPromptText("Answer 18");
		
		HBox HBox18 = new HBox(2);
		HBox18.getChildren().addAll(match18, answer18);
		HBox18.setSpacing(10); 
		HBox18.setAlignment(Pos.CENTER);
		
		TextField match19 = new TextField();
		match19.setPromptText("Match 19");
		
		TextField answer19 = new TextField();
		answer19.setPromptText("Answer 19");
		
		HBox HBox19 = new HBox(2);
		HBox19.getChildren().addAll(match19, answer19);
		HBox19.setSpacing(10); 
		HBox19.setAlignment(Pos.CENTER);
		
		TextField match20 = new TextField();
		match20.setPromptText("Match 20");
		
		TextField answer20 = new TextField();
		answer20.setPromptText("Answer 20");
		
		HBox HBox20 = new HBox(2);
		HBox20.getChildren().addAll(match20, answer20);
		HBox20.setSpacing(10); 
		HBox20.setAlignment(Pos.CENTER);
		
		//Create Question Button
		Button createQuestion = new Button("Create Question");
		createQuestion.setOnAction(e ->
		{
			Connection conn = null;
	        String sql;
	        // MySQL JDBC URL format��jdbc:mysql://hostaddress��port/database_name?parameter=value
	        // assign useUnicode and characterEncoding
	        
	        final String URL = "jdbc:mysql://216.189.155.175:3307/SE_Project";
	        final String USER = "test";
	        final String PASSWORD = "123456";
	        
	        Date date = new Date();
		    SimpleDateFormat ft = new SimpleDateFormat ("yyyyMMddHHmmss");
	        
	        String[] temp = new String[4];
	        temp = course_Info_MQ.split("\\|");
	        
	        String college_Name = temp[0];
	        String course_ID = temp[1];
	        String exam_Name = temp[3];
	        String question_ID = course_ID + exam_Name + ft.format(date);
	        String question_Text = questionText.getText();
	        String matching_Text = match1.getText() + "|" + 
	        					   match2.getText() + "|" + 
	        					   match3.getText() + "|" + 
	        					   match4.getText() + "|" + 
	        					   match5.getText() + "|" + 
	        					   match6.getText() + "|" + 
	        					   match7.getText() + "|" + 
	        					   match8.getText() + "|" + 
	        					   match9.getText() + "|" + 
	        					   match10.getText() + "|" + 
	        					   match11.getText() + "|" + 
	        					   match12.getText() + "|" + 
	        					   match13.getText() + "|" + 
	        					   match14.getText() + "|" + 
	        					   match15.getText() + "|" + 
	        					   match16.getText() + "|" + 
	        					   match17.getText() + "|" + 
	        					   match18.getText() + "|" + 
	        					   match19.getText() + "|" + 
	        					   match20.getText();
	        
	        while(matching_Text.endsWith("|")) {
	        	matching_Text = matching_Text.substring(0, matching_Text.length()-1);
	        }
	        					   
	        String answer_Text = answer1.getText() + "|" + 
					   			 answer2.getText() + "|" + 
					   			 answer3.getText() + "|" + 
					   			 answer4.getText() + "|" + 
					   			 answer5.getText() + "|" + 
					   			 answer6.getText() + "|" + 
					   			 answer7.getText() + "|" + 
					   			 answer8.getText() + "|" + 
					   			 answer9.getText() + "|" + 
					   			 answer10.getText() + "|" + 
					   			 answer11.getText() + "|" + 
					   			 answer12.getText() + "|" + 
					   			 answer13.getText() + "|" + 
					   			 answer14.getText() + "|" + 
					   			 answer15.getText() + "|" + 
					   			 answer16.getText() + "|" + 
					   			 answer17.getText() + "|" + 
					   			 answer18.getText() + "|" + 
					   			 answer19.getText() + "|" + 
					   			 answer20.getText();
	        
	        while(answer_Text.endsWith("|")) {
	        	answer_Text = answer_Text.substring(0, answer_Text.length()-1);
	        }
	        
	        int weight = 1;
	        try {
	        	weight = Integer.parseInt(weightText.getText());
	        } catch (Exception e1) {
	            e1.printStackTrace();
	            Alert alert = new Alert(AlertType.INFORMATION);
	            alert.setTitle("Wrong format!");
	            alert.setHeaderText(null);
	            alert.setContentText("Please input a correct format of number. Please reboot the program refresh the wrong cache.");

	            alert.showAndWait();
	            System.exit(0);
	        } 
	        
	        if(stringNumbers(matching_Text) != stringNumbers(answer_Text)) {
	        	Alert alert = new Alert(AlertType.INFORMATION);
	            alert.setTitle("Wrong pairs!");
	            alert.setHeaderText(null);
	            alert.setContentText("You have input different number of matchings and answers. Please input the same number of matchings and answers");

	            alert.showAndWait();
	            return;
	        }
	        
			try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("MySQL Driver is running successfully");
				conn = DriverManager.getConnection(URL, USER, PASSWORD);
				Statement stmt = conn.createStatement();
				
				sql = "insert into MQ_Table(College_Name, Course_ID, Question_ID, Question_Text, Matching_Text, Answer_Text, Weight) values ('" + college_Name + "', '" + course_ID + "', '" + question_ID + "', '" + question_Text + "', '" + matching_Text + "', '" + answer_Text +  "', '" + weight + "')";//NOT DONE YET
				int result = stmt.executeUpdate(sql);// if return -1 then it crashed
		           if (result != -1) {
		               System.out.println("Successful execution!");
		               Alert alert = new Alert(AlertType.INFORMATION);
		               alert.setTitle("Successful execution!");
		               alert.setHeaderText(null);
		               alert.setContentText("You have created one record successfully! You can continue to create exams or close the window.");

		               alert.showAndWait();
		           }
			} catch (SQLException e1) {
	            System.out.println("MySQL executed unsuccessfully.");
	            e1.printStackTrace();
	        } catch (Exception e1) {
	            e1.printStackTrace();
	        } finally {
	        	try {
					conn.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
			
		});
		
		//Close Window
		Button closeButton = new Button("      Close      ");
		closeButton.setStyle("-fx-background-color: #FA8072;");
		closeButton.setOnAction(e -> window.close());
		
		HBox functionHBox = new HBox(2);
		functionHBox.getChildren().addAll(createQuestion, closeButton);
		functionHBox.setPadding(new Insets(15, 12, 15, 12)); 
		functionHBox.setSpacing(10); 
		functionHBox.setAlignment(Pos.CENTER);
		
		//Layout
		VBox layout = new VBox(30);
		layout.getChildren().addAll(
					top, questionText, weightText, HBox1, HBox2, HBox3, HBox4, HBox5, HBox6, HBox7, HBox8, HBox9, HBox10, HBox11, HBox12, HBox13, HBox14, HBox15, HBox16, HBox17, HBox18, HBox19, HBox20,
					functionHBox
				);
		layout.setPadding(new Insets(5, 20, 5, 20));	
		layout.setSpacing(1);
		//Scene setup
		Scene scene = new Scene(layout);
		scene.getStylesheets().add("theme.css");
		window.setScene(scene);
		window.showAndWait();
	}
	public static int stringNumbers(String str)  
    {  
		int counter = 0;
        if (str.indexOf("|")==-1)  
        {  
            return 0;  
        }  
        else if(str.indexOf("|") != -1)  
        {  
            counter++;  
            stringNumbers(str.substring(str.indexOf("|")+1));  
            return counter;  
        }  
        return 0;  
    }  

}
